/* =========================================================
 * ZeroCOS HAL — QEMU virt (Tier 3, RV32IMAC)
 *
 * Display: ANSI 16-color block-art, diff renderer
 * Sound:   APC escape sideband → host shell wrapper
 *
 * Sound architecture:
 * -------------------
 * The guest encodes sound as an ANSI APC string written to
 * the same UART as display output:
 *
 *    ESC _ BEEP:freq:ms ESC \
 *    e.g.  \033_BEEP:440:100\033\\
 *
 * APC (Application Program Command) sequences are private-
 * use and silently ignored by every terminal emulator, so
 * they pass through to stdout invisibly.
 *
 * The run.sh wrapper script intercepts them with a Python
 * line filter and calls 'beep' (or 'paplay' fallback) on
 * the host for real pitched audio.
 *
 * hal_sound_off() sends BEEP:0:0 which the wrapper uses to
 * stop any currently playing tone.
 *
 * NS16550a UART0 @ 0x10000000
 * CLINT mtime    @ 0x0200BFF8
 * ========================================================= */

#include "zcos_config.h"
#include "zcos_hal.h"
#include "zcos_input.h"

#if defined(ZCOS_CHIP_QEMU)

/* =========================================================
 *  CLINT
 * ========================================================= */
#define CLINT_MTIME_LO  (*(volatile u32*)(0x0200BFF8u))

/* =========================================================
 *  NS16550a UART0
 * ========================================================= */
#define UART0_BASE  0x10000000u
#define UART0_RBR   (*(volatile u8*)(UART0_BASE + 0x00u))
#define UART0_THR   (*(volatile u8*)(UART0_BASE + 0x00u))
#define UART0_LSR   (*(volatile u8*)(UART0_BASE + 0x05u))

/* =========================================================
 *  Global Volume State (0 to 100)
 * ========================================================= */
static u8 s_zcos_volume = 100u;

void hal_volume_set(u8 vol) {
    if (vol > 100u) vol = 100u;
    s_zcos_volume = vol;
}

int hal_volume_get(void) {
    return (int)s_zcos_volume;
}

/* =========================================================
 *  Classic 16-color CRT/VGA palette
 *
 *  Index: 0=Black  1=DkRed     2=DkGreen   3=Brown
 *         4=DkBlue 5=DkMagenta 6=DkCyan    7=LtGray
 *         8=DkGray 9=BrRed     10=BrGreen  11=Yellow
 *        12=BrBlue 13=BrMagenta 14=BrCyan  15=White
 * ========================================================= */
static const u8 vga_r[16] = {
     0,170,  0,170,  0,170,  0,170,
    85,255, 85,255, 85,255, 85,255
};
static const u8 vga_g[16] = {
     0,  0,170,170,  0,  0,170,170,
    85, 85,255,255, 85, 85,255,255
};
static const u8 vga_b[16] = {
     0,  0,  0,  0,170,170,170,170,
    85, 85, 85, 85,255,255,255,255
};

/* ANSI fg codes: 30-37 normal, 90-97 bright */
static const u8 ansi_fg[16] = {
    30,31,32,33,34,35,36,37,
    90,91,92,93,94,95,96,97
};
/* ANSI bg codes: 40-47 normal, 100-107 bright */
static const u8 ansi_bg[16] = {
     40, 41, 42, 43, 44, 45, 46, 47,
    100,101,102,103,104,105,106,107
};

/* =========================================================
 *  Pixel framebuffer
 * ========================================================= */
static u32 s_px[ZCOS_DISP_W * ZCOS_DISP_H];

/* =========================================================
 *  Cell double-buffer for diff rendering
 *  Each cell = 1 terminal char = 1×2 pixels (▄ block)
 *  Packed u8: high nibble = top pixel VGA idx,
 *             low  nibble = bot pixel VGA idx
 * ========================================================= */
#define CELL_COLS  ZCOS_DISP_W
#define CELL_ROWS  (ZCOS_DISP_H / 2u)
#define CELL_COUNT (CELL_COLS * CELL_ROWS)

static u8 s_front[CELL_COUNT];
static u8 s_back [CELL_COUNT];

/* =========================================================
 *  UART helpers
 * ========================================================= */
static void uart_raw(char c) {
    while (!(UART0_LSR & 0x20u)) {}
    UART0_THR = (u8)c;
}
static void uart_str(const char *s) {
    while (*s) uart_raw(*s++);
}
static void uart_u8dec(u8 v) {
    if (v >= 100u) uart_raw((char)('0' + v/100u));
    if (v >=  10u) uart_raw((char)('0' + (v/10u)%10u));
    uart_raw((char)('0' + v%10u));
}
/* Emit a u32 decimal — for sound freq values */
static void uart_u32dec(u32 v) {
    if (!v) { uart_raw('0'); return; }
    char buf[10];
    u8 i = 0;
    while (v) { buf[i++] = (char)('0' + v%10u); v /= 10u; }
    while (i--) uart_raw(buf[i]);
}

/* =========================================================
 *  Color quantization: RGB888 → nearest VGA index
 * ========================================================= */
static u8 nearest_vga(u8 r, u8 g, u8 b) {
    u8  best    = 0u;
    u32 best_d = 0xFFFFFFFFu;
    for (u8 i = 0; i < 16u; i++) {
        s32 dr = (s32)r - (s32)vga_r[i];
        s32 dg = (s32)g - (s32)vga_g[i];
        s32 db = (s32)b - (s32)vga_b[i];
        /* weight green (human eye sensitivity) */
        u32 d = (u32)(dr*dr) + (u32)(dg*dg*2) + (u32)(db*db);
        if (d < best_d) { best_d = d; best = i; }
    }
    return best;
}

/* =========================================================
 *  hal_init
 * ========================================================= */
void hal_init(void) {
    for (u32 i = 0; i < ZCOS_DISP_W * ZCOS_DISP_H; i++)
        s_px[i] = 0u;
    /* 0xFF forces full repaint on first flush */
    for (u32 i = 0; i < CELL_COUNT; i++)
        s_front[i] = 0xFFu;
}

/* =========================================================
 *  hal_disp_init
 * ========================================================= */
void hal_disp_init(void) {
    uart_str("\033[?25l"   /* hide cursor  */
             "\033[2J"    /* clear screen */
             "\033[H");   /* top-left     */
}

/* =========================================================
 *  Color mapping (1-bit binary or VGA index → XRGB8888)
 * ========================================================= */
static u32 color_to_xrgb(u8 c) {
    if (c == 0u) return 0x000000u;
    if (c == 1u) return 0xFFFFFFu;
    u8 r = vga_r[c & 0x0Fu];
    u8 g = vga_g[c & 0x0Fu];
    u8 b = vga_b[c & 0x0Fu];
    return ((u32)r << 16) | ((u32)g << 8) | b;
}

void hal_disp_fill(u8 color) {
    u32 px = color_to_xrgb(color);
    u32 n  = ZCOS_DISP_W * ZCOS_DISP_H;
    for (u32 i = 0; i < n; i++) s_px[i] = px;
}

void hal_disp_pixel(u16 x, u16 y, u8 c) {
    if (x >= ZCOS_DISP_W || y >= ZCOS_DISP_H) return;
    s_px[(u32)y * ZCOS_DISP_W + x] = color_to_xrgb(c);
}

void hal_disp_rect(u16 x, u16 y, u16 w, u16 h, u8 c) {
    if (!w || !h) return;
    u16 x1 = x + w; if (x1 > ZCOS_DISP_W) x1 = ZCOS_DISP_W;
    u16 y1 = y + h; if (y1 > ZCOS_DISP_H) y1 = ZCOS_DISP_H;
    u32 px = color_to_xrgb(c);
    for (u16 row = y; row < y1; row++) {
        u32 *line = &s_px[(u32)row * ZCOS_DISP_W + x];
        for (u16 col = 0; col < (u16)(x1-x); col++)
            line[col] = px;
    }
}

void hal_disp_tile1bpp(u16 x, u16 y, const u8 *tile8, u8 fg, u8 bg) {
    u32 pfg = color_to_xrgb(fg);
    u32 pbg = color_to_xrgb(bg);
    for (u8 row = 0; row < 8u; row++) {
        u8  bits = tile8[row];
        u32 *line = &s_px[((u32)y+row)*ZCOS_DISP_W + x];
        for (u8 col = 0; col < 8u; col++)
            line[col] = (bits & (0x80u >> col)) ? pfg : pbg;
    }
}

/* =========================================================
 *  hal_disp_flush — diff renderer
 *
 *  Only emits escape codes for cells that changed since
 *  last frame. Static scene = zero UART traffic = no flicker.
 * ========================================================= */
void hal_disp_flush(void) {
    /* Quantize pixel buffer → back cell buffer */
    for (u16 tr = 0; tr < CELL_ROWS; tr++) {
        for (u16 tc = 0; tc < CELL_COLS; tc++) {
            u32 top = s_px[(u32)(tr*2u  ) * ZCOS_DISP_W + tc];
            u32 bot = s_px[(u32)(tr*2u+1u) * ZCOS_DISP_W + tc];
            u8 ci_top = nearest_vga(
                (u8)(top>>16),(u8)(top>>8),(u8)top);
            u8 ci_bot = nearest_vga(
                (u8)(bot>>16),(u8)(bot>>8),(u8)bot);
            s_back[tr * CELL_COLS + tc] =
                (u8)((ci_top << 4) | ci_bot);
        }
    }

    /* Diff + emit */
    u8 cur_fg = 0xFFu, cur_bg = 0xFFu;
    u16 cursor_row = 0xFFFFu, cursor_col = 0xFFFFu;

    for (u16 tr = 0; tr < CELL_ROWS; tr++) {
        for (u16 tc = 0; tc < CELL_COLS; tc++) {
            u32 idx  = (u32)tr * CELL_COLS + tc;
            u8  cell = s_back[idx];
            if (cell == s_front[idx]) continue;

            u8 bg_idx = (u8)(cell >> 4);
            u8 fg_idx = (u8)(cell & 0xFu);

            /* Move cursor if not already positioned here */
            if (cursor_row != tr || cursor_col != tc) {
                uart_str("\033[");
                uart_u8dec((u8)(tr + 1u));
                uart_raw(';');
                uart_u8dec((u8)(tc + 1u));
                uart_raw('H');
                cursor_row = tr;
                cursor_col = tc;
            }

            /* Emit color change only when needed */
            if (fg_idx != cur_fg || bg_idx != cur_bg) {
                uart_str("\033[");
                uart_u8dec(ansi_fg[fg_idx]);
                uart_raw(';');
                uart_u8dec(ansi_bg[bg_idx]);
                uart_raw('m');
                cur_fg = fg_idx;
                cur_bg = bg_idx;
            }

            /* ▄ U+2584 — top pixel=bg, bottom pixel=fg */
            uart_raw('\xe2');
            uart_raw('\x96');
            uart_raw('\x84');

            s_front[idx] = cell;
            cursor_col++;
            /* if cursor wrapped off end, mark unknown */
            if (cursor_col >= CELL_COLS)
                cursor_col = 0xFFFFu;
        }
    }

    if (cur_fg != 0xFFu)
        uart_str("\033[0m");
}

/* =========================================================
 *  Sound — APC escape sideband
 * ========================================================= */
static u32 s_last_freq = 0u;
static u32 s_tone_start_ms = 0u;

void hal_sound_init(void) {
    s_last_freq     = 0u;
    s_tone_start_ms = 0u;
}

void hal_sound_tone(u32 freq_hz) {
    if (!freq_hz || s_zcos_volume == 0u) { hal_sound_off(); return; }
    s_last_freq     = freq_hz;
    s_tone_start_ms = hal_tick_get();

    uart_raw('\033'); uart_raw('_');
    uart_str("BEEP:");
    uart_u32dec(freq_hz);
    uart_str(":0");
    uart_raw('\033'); uart_raw('\\');
}

void hal_sound_off(void) {
    if (!s_last_freq) return;

    u32 dur = hal_tick_get() - s_tone_start_ms;
    if (dur == 0u) dur = 1u;

    uart_raw('\033'); uart_raw('_');
    uart_str("BEEP:");
    uart_u32dec(s_last_freq);
    uart_raw(':');
    uart_u32dec(dur);
    uart_raw('\033'); uart_raw('\\');

    s_last_freq = 0u;
}

/* =========================================================
 *  Input — NS16550a non-blocking
 * ========================================================= */
static u8 s_btn_state = 0u;

u8 hal_input_read(void) {
    if (UART0_LSR & 0x01u) {
        u8 ch = UART0_RBR;
        switch (ch) {
            case 'w': case 'W': s_btn_state = BTN_UP;    break;
            case 's': case 'S': s_btn_state = BTN_DOWN;  break;
            case 'a': case 'A': s_btn_state = BTN_LEFT;  break;
            case 'd': case 'D': s_btn_state = BTN_RIGHT; break;
            case 'z': case 'Z': s_btn_state = BTN_A;     break;
            case 'x': case 'X': s_btn_state = BTN_B;     break;
            case '\r':          s_btn_state = BTN_START; break;
            case '\t':          s_btn_state = BTN_SELECT; break;
            default:            s_btn_state = 0u;        break;
        }
    } else {
        s_btn_state = 0u;
    }
    return s_btn_state;
}

/* =========================================================
 *  UART
 * ========================================================= */
void hal_uart_putc(char c) {
    while (!(UART0_LSR & 0x20u)) {}
    UART0_THR = (u8)c;
}
void hal_uart_puts(const char *s) {
    while (*s) hal_uart_putc(*s++);
}
void hal_uart_puthex(u32 v) {
    hal_uart_puts("0x");
    for (s8 i = 28; i >= 0; i -= 4) {
        u8 nib = (u8)((v >> i) & 0xFu);
        hal_uart_putc((char)(nib < 10u ?
            (char)((u8)'0' + nib) :
            (char)((u8)'A' + nib - 10u)));
    }
}

/* =========================================================
 *  Timing — CLINT mtime
 * ========================================================= */
u32 hal_tick_get(void) {
    return CLINT_MTIME_LO / 10000u;
}
void hal_delay_us(u32 us) {
    u32 start = hal_tick_get();
    u32 ms = (us < 1000u) ? 1u : us/1000u;
    while ((hal_tick_get() - start) < ms) {}
}
void hal_delay_ms(u32 ms) {
    u32 start = hal_tick_get();
    while ((hal_tick_get() - start) < ms) {}
}

ZCOS_NORETURN void hal_reset(void) {
    uart_str("\r\n[RESET]\r\n");
    for (;;) {}
}

#endif /* ZCOS_CHIP_QEMU */