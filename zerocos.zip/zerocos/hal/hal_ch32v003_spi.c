/*
 * ZeroCOS — Copyright (C) 2026 asuscat
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

/* =========================================================
 * ZeroCOS HAL — CH32V003 / CH32V203 (Tier 0 real hardware)
 * ========================================================= */

#include "zcos_config.h"
#include "zcos_hal.h"
#include "zcos_input.h"

#if defined(ZCOS_CHIP_CH32V003) || defined(ZCOS_CHIP_CH32V203) || defined(ZCOS_CHIP_GD32VF103)

#define RCC_BASE        0x40021000u
#define GPIOA_BASE      0x40010800u
#define GPIOC_BASE      0x40011000u
#define GPIOD_BASE      0x40011400u
#define SPI1_BASE       0x40013000u
#define TIM1_BASE       0x40012C00u
#define USART1_BASE     0x40013800u

#define RCC_CTLR        (*(volatile u32*)(RCC_BASE + 0x00u))
#define RCC_CFGR0       (*(volatile u32*)(RCC_BASE + 0x04u))
#define RCC_APB2PCENR   (*(volatile u32*)(RCC_BASE + 0x18u))

#define RCC_AFIOEN      (1u <<  0)
#define RCC_IOPAEN      (1u <<  2)
#define RCC_IOPCEN      (1u <<  4)
#define RCC_IOPDEN      (1u <<  5)
#define RCC_SPI1EN      (1u << 12)
#define RCC_TIM1EN      (1u << 11)
#define RCC_USART1EN    (1u << 14)

typedef struct {
    volatile u32 CFGLR, CFGHR, INDR, OUTDR, BSHR, BCR, LCKR;
} GPIO_t;

#define GPIOA ((GPIO_t*)GPIOA_BASE)
#define GPIOC ((GPIO_t*)GPIOC_BASE)
#define GPIOD ((GPIO_t*)GPIOD_BASE)

#define GPIO_OUT_PP_50  0x3u
#define GPIO_OUT_AF_PP  0xBu
#define GPIO_IN_PU      0x8u

static void gpio_mode(GPIO_t *port, u8 pin, u8 mode) {
    if (pin < 8u) {
        u32 sh = (u32)pin * 4u;
        port->CFGLR = (port->CFGLR & ~(0xFu << sh)) | ((u32)mode << sh);
    } else {
        u32 sh = ((u32)pin - 8u) * 4u;
        port->CFGHR = (port->CFGHR & ~(0xFu << sh)) | ((u32)mode << sh);
    }
}
static void gpio_high(GPIO_t *p, u8 pin) { p->BSHR = 1u << pin; }
static void gpio_low (GPIO_t *p, u8 pin) { p->BCR  = 1u << pin; }
static u8   gpio_read(GPIO_t *p, u8 pin) { return (u8)((p->INDR >> pin) & 1u); }

#define SPI1_CTLR1   (*(volatile u32*)(SPI1_BASE + 0x00u))
#define SPI1_STATR   (*(volatile u32*)(SPI1_BASE + 0x08u))
#define SPI1_DATAR   (*(volatile u32*)(SPI1_BASE + 0x0Cu))

#define SPI_SR_TXE   (1u << 1)
#define SPI_SR_BSY   (1u << 7)
#define SPI_CR1_SPE  (1u << 6)
#define SPI_CR1_MSTR (1u << 2)
#define SPI_CR1_SSM  (1u << 9)
#define SPI_CR1_SSI  (1u << 8)

static void spi_send(u8 b) {
    while (!(SPI1_STATR & SPI_SR_TXE)) {}
    SPI1_DATAR = b;
}
static void spi_flush(void) {
    while (SPI1_STATR & SPI_SR_BSY) {}
}

#define TFT_CS_LOW()    gpio_low (GPIOD, 0)
#define TFT_CS_HIGH()   gpio_high(GPIOD, 0)
#define TFT_DC_CMD()    gpio_low (GPIOD, 1)
#define TFT_DC_DATA()   gpio_high(GPIOD, 1)
#define TFT_RST_LOW()   gpio_low (GPIOD, 2)
#define TFT_RST_HIGH()  gpio_high(GPIOD, 2)

static void tft_cmd(u8 c)  { TFT_DC_CMD();  spi_send(c); spi_flush(); }
static void tft_data(u8 d) { TFT_DC_DATA(); spi_send(d); }

static void tft_data16(u16 d) {
    TFT_DC_DATA();
    spi_send((u8)(d >> 8));
    spi_send((u8)(d));
}

static void tft_window(u16 x0, u16 y0, u16 x1, u16 y1) {
    tft_cmd(0x2A); tft_data16(x0); tft_data16(x1);
    tft_cmd(0x2B); tft_data16(y0); tft_data16(y1);
    tft_cmd(0x2C);
}

#define TIM1_CR1    (*(volatile u32*)(TIM1_BASE + 0x00u))
#define TIM1_CCMR1  (*(volatile u32*)(TIM1_BASE + 0x18u))
#define TIM1_CCER   (*(volatile u32*)(TIM1_BASE + 0x20u))
#define TIM1_PSC    (*(volatile u32*)(TIM1_BASE + 0x28u))
#define TIM1_ARR    (*(volatile u32*)(TIM1_BASE + 0x2Cu))
#define TIM1_CCR1   (*(volatile u32*)(TIM1_BASE + 0x34u))
#define TIM1_BDTR   (*(volatile u32*)(TIM1_BASE + 0x44u))

#define USART1_STATR (*(volatile u32*)(USART1_BASE + 0x00u))
#define USART1_DATAR (*(volatile u32*)(USART1_BASE + 0x04u))
#define USART1_BRR   (*(volatile u32*)(USART1_BASE + 0x08u))
#define USART1_CTLR1 (*(volatile u32*)(USART1_BASE + 0x0Cu))

/* =========================================================
 *  Frequency State
 * ========================================================= */
static u32 s_current_freq = 0u;

void hal_volume_set(u8 vol) { (void)vol; }
int hal_volume_get(void) { return 100; }

static volatile u32 s_tick_ms = 0u;

u32 hal_tick_get(void) { return s_tick_ms; }

extern void _hal_delay_us_asm(u32 us, u32 cycles_per_us_div4);

void hal_delay_us(u32 us) {
    _hal_delay_us_asm(us, ZCOS_CLOCK_HZ / 1000000u / 4u);
}

void hal_delay_ms(u32 ms) {
    for (u32 i = 0; i < ms; i++) {
        hal_delay_us(1000u);
        s_tick_ms++;
    }
}

void hal_init(void) {
    RCC_CFGR0 = (RCC_CFGR0 & ~(0xFu << 18)) |
                (0x1u << 18) |
                (0u    << 16);
    RCC_CTLR |= (1u << 24);
    while (!(RCC_CTLR & (1u << 25))) {}
    RCC_CFGR0 = (RCC_CFGR0 & ~0x3u) | 0x2u;
    while (((RCC_CFGR0 >> 2) & 0x3u) != 0x2u) {}

    RCC_APB2PCENR |= RCC_IOPAEN | RCC_IOPCEN | RCC_IOPDEN |
                     RCC_SPI1EN | RCC_TIM1EN | RCC_USART1EN |
                     RCC_AFIOEN;

    u8 btn_pa[] = {0, 2, 3, 4, 5};
    for (u8 i = 0; i < 5u; i++) {
        gpio_mode(GPIOA, btn_pa[i], GPIO_IN_PU);
        GPIOA->OUTDR |= (1u << btn_pa[i]);
    }
    gpio_mode(GPIOC, 0, GPIO_IN_PU); GPIOC->OUTDR |= (1u << 0);
    gpio_mode(GPIOD, 3, GPIO_IN_PU); GPIOD->OUTDR |= (1u << 3);
    gpio_mode(GPIOD, 4, GPIO_IN_PU); GPIOD->OUTDR |= (1u << 4);

    gpio_mode(GPIOC, 5, GPIO_OUT_AF_PP);
    gpio_mode(GPIOC, 6, GPIO_OUT_AF_PP);

    gpio_mode(GPIOD, 0, GPIO_OUT_PP_50);
    gpio_mode(GPIOD, 1, GPIO_OUT_PP_50);
    gpio_mode(GPIOD, 2, GPIO_OUT_PP_50);

    SPI1_CTLR1 = SPI_CR1_MSTR | SPI_CR1_SSM | SPI_CR1_SSI |
                 (0u << 3) |
                 SPI_CR1_SPE;

    gpio_mode(GPIOD, 5, GPIO_OUT_AF_PP);
    USART1_BRR   = ZCOS_CLOCK_HZ / ZCOS_UART_BAUD;
    USART1_CTLR1 = (1u << 3) | (1u << 13);

    gpio_mode(GPIOA, 1, GPIO_OUT_AF_PP);
}

void hal_disp_init(void) {
    TFT_CS_HIGH();
    TFT_RST_LOW();  hal_delay_ms(50u);
    TFT_RST_HIGH(); hal_delay_ms(150u);

    TFT_CS_LOW();
    tft_cmd(0x01); hal_delay_ms(150u);
    tft_cmd(0x11); hal_delay_ms(120u);
    tft_cmd(0x3A); tft_data(0x05);
    tft_cmd(0x36); tft_data(0x00);
    tft_cmd(0x29); hal_delay_ms(10u);
    TFT_CS_HIGH();

    hal_disp_fill(COL_BLACK);
}

/* =========================================================
 * SPI Storage Tier (External Game Storage via SPI1)
 * ========================================================= */

#define SD_CS_LOW()   gpio_low(GPIOC, 4)
#define SD_CS_HIGH()  gpio_high(GPIOC, 4)

void hal_spi_init(void) {
    // Configure PC4 as Push-Pull Output for SD/Flash Chip Select
    gpio_mode(GPIOC, 4, GPIO_OUT_PP_50);
    SD_CS_HIGH();
}

void hal_spi_read_block(u32 address, u8 *dest, u16 len) {
    SD_CS_LOW();

    // Send Read Command (0x03)
    spi_send(0x03);

    // Send 24-bit Big-Endian Address
    spi_send((u8)(address >> 16));
    spi_send((u8)(address >> 8));
    spi_send((u8)(address));

    // Clock out data bytes into destination buffer
    for (u16 i = 0; i < len; i++) {
        spi_send(0xFF); // Send dummy byte to clock in data
        while (!(SPI1_STATR & (1u << 0))) {} // Wait for RXNE (Receive buffer not empty)
        dest[i] = (u8)SPI1_DATAR;
    }

    spi_flush();
    SD_CS_HIGH();
}

/* =========================================================
 *  Color mapping: 1-bit binary (0/1) → RGB565
 * ========================================================= */
static inline u16 color_to_rgb565(u8 c) {
    return (c == 0u) ? 0x0000u : 0xFFFFu;
}

void hal_disp_fill(u8 color) {
    u16 rgb = color_to_rgb565(color);
    TFT_CS_LOW();
    tft_window(0u, 0u, ZCOS_DISP_W - 1u, ZCOS_DISP_H - 1u);
    TFT_DC_DATA();
    u8 hi = (u8)(rgb >> 8), lo = (u8)rgb;
    u32 n = (u32)ZCOS_DISP_W * ZCOS_DISP_H;
    while (n--) { spi_send(hi); spi_send(lo); }
    spi_flush();
    TFT_CS_HIGH();
}

void hal_disp_pixel(u16 x, u16 y, u8 c) {
    if (x >= ZCOS_DISP_W || y >= ZCOS_DISP_H) return;
    TFT_CS_LOW();
    tft_window(x, y, x, y);
    tft_data16(color_to_rgb565(c));
    spi_flush();
    TFT_CS_HIGH();
}

void hal_disp_rect(u16 x, u16 y, u16 w, u16 h, u8 c) {
    if (!w || !h) return;
    u16 rgb = color_to_rgb565(c);
    TFT_CS_LOW();
    tft_window(x, y, (u16)(x+w-1u), (u16)(y+h-1u));
    TFT_DC_DATA();
    u8 hi = (u8)(rgb >> 8), lo = (u8)rgb;
    u32 n = (u32)w * h;
    while (n--) { spi_send(hi); spi_send(lo); }
    spi_flush();
    TFT_CS_HIGH();
}

void hal_disp_tile1bpp(u16 x, u16 y, const u8 *tile8, u8 fg, u8 bg) {
    u16 f_rgb = color_to_rgb565(fg);
    u16 b_rgb = color_to_rgb565(bg);
    TFT_CS_LOW();
    tft_window(x, y, (u16)(x+7u), (u16)(y+7u));
    TFT_DC_DATA();
    u8 fhi = (u8)(f_rgb >> 8), flo = (u8)f_rgb;
    u8 bhi = (u8)(b_rgb >> 8), blo = (u8)b_rgb;
    for (u8 row = 0; row < 8u; row++) {
        u8 bits = tile8[row];
        for (u8 col = 0; col < 8u; col++) {
            if (bits & (0x80u >> col)) {
                spi_send(fhi); spi_send(flo);
            } else {
                spi_send(bhi); spi_send(blo);
            }
        }
    }
    spi_flush();
    TFT_CS_HIGH();
}

void hal_disp_flush(void) {}

/* =========================================================
 *  Sound — TIM1 CH1 PWM square wave on PA1
 * ========================================================= */
void hal_sound_init(void) {
    s_current_freq = 0u;

    TIM1_CR1  = 0u;
    TIM1_PSC  = 0u;
    TIM1_ARR  = 0u;
    TIM1_CCR1 = 0u;

    TIM1_CCMR1 = (0x6u << 4) | (1u << 3);
    TIM1_CCER  = (1u << 0);
    TIM1_BDTR  = (1u << 15);
}

void hal_sound_tone(u32 freq_hz) {
    if (!freq_hz) { hal_sound_off(); return; }
    s_current_freq = freq_hz;

    u32 psc = 0u;
    u32 arr = (ZCOS_CLOCK_HZ / freq_hz) - 1u;

    while (arr > 0xFFFFu && psc < 0xFFFFu) {
        psc++;
        arr = (ZCOS_CLOCK_HZ / (freq_hz * (psc + 1u))) - 1u;
    }

    TIM1_PSC  = psc;
    TIM1_ARR  = arr;
    TIM1_CCR1 = arr >> 1u;
    TIM1_CR1  = (1u << 0);
}

void hal_sound_off(void) {
    TIM1_CR1     = 0u;
    TIM1_CCR1    = 0u;
    s_current_freq = 0u;
}

u8 hal_input_read(void) {
    u8 s = 0u;
    if (!gpio_read(GPIOA, 0)) s |= BTN_UP;
    if (!gpio_read(GPIOC, 0)) s |= BTN_DOWN;
    if (!gpio_read(GPIOA, 2)) s |= BTN_LEFT;
    if (!gpio_read(GPIOA, 3)) s |= BTN_RIGHT;
    if (!gpio_read(GPIOA, 4)) s |= BTN_A;
    if (!gpio_read(GPIOA, 5)) s |= BTN_B;
    if (!gpio_read(GPIOD, 3)) s |= BTN_SELECT;
    if (!gpio_read(GPIOD, 4)) s |= BTN_START;
    return s;
}

void hal_uart_putc(char c) {
    while (!(USART1_STATR & (1u << 7))) {}
    USART1_DATAR = (u8)c;
}
void hal_uart_puts(const char *s) {
    while (*s) hal_uart_putc(*s++);
}
void hal_uart_puthex(u32 v) {
    hal_uart_puts("0x");
    for (s8 i = 28; i >= 0; i -= 4) {
        u8 n = (u8)((v >> i) & 0xFu);
        hal_uart_putc((char)(n < 10u ? '0' + (char)n : 'A' + (char)(n - 10u)));
    }
}

ZCOS_NORETURN void hal_reset(void) {
    for (;;) {}
}

#endif /* ZCOS_CHIP_CH32 */