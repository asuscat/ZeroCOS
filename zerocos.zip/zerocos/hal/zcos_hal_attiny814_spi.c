/* =========================================================
 * ZeroCOS HAL — ATtiny814 SPI Tier (Tier 6 / 1-bit Monochrome)
 * ========================================================= */

#ifndef F_CPU
#define F_CPU 3333333UL
#endif

#include <avr/io.h>
#include <avr/interrupt.h>
#include <avr/cpufunc.h>
#include "zcos_config.h"
#include "zcos_hal.h"
#include "zcos_input.h"

#if defined(ZCOS_CHIP_ATTINY814) || defined(__AVR_ATtiny814__)

#define TFT_CS_PORT   PORTA
#define TFT_CS_PIN    4
#define TFT_DC_PORT   PORTA
#define TFT_DC_PIN    5
#define TFT_RST_PORT  PORTA
#define TFT_RST_PIN   6

#define SD_CS_PORT    PORTA
#define SD_CS_PIN     7

#define TFT_CS_LOW()   (TFT_CS_PORT.OUTCLR = (1 << TFT_CS_PIN))
#define TFT_CS_HIGH()  (TFT_CS_PORT.OUTSET = (1 << TFT_CS_PIN))
#define TFT_DC_CMD()   (TFT_DC_PORT.OUTCLR = (1 << TFT_DC_PIN))
#define TFT_DC_DATA()  (TFT_DC_PORT.OUTSET = (1 << TFT_DC_PIN))
#define TFT_RST_LOW()  (TFT_RST_PORT.OUTCLR = (1 << TFT_RST_PIN))
#define TFT_RST_HIGH() (TFT_RST_PORT.OUTSET = (1 << TFT_RST_PIN))

#define SD_CS_LOW()    (SD_CS_PORT.OUTCLR = (1 << SD_CS_PIN))
#define SD_CS_HIGH()   (SD_CS_PORT.OUTSET = (1 << SD_CS_PIN))

static u32 s_current_freq = 0u;
static volatile u32 s_tick_ms = 0u;

void hal_volume_set(u8 vol) { (void)vol; }
int hal_volume_get(void) { return 100; }
u32 hal_tick_get(void) { return s_tick_ms; }

void hal_delay_us(u32 us) {
    while (us--) {
        __builtin_avr_nop(); __builtin_avr_nop(); __builtin_avr_nop(); __builtin_avr_nop();
    }
}

void hal_delay_ms(u32 ms) {
    while (ms--) {
        hal_delay_us(1000u);
        s_tick_ms++;
    }
}

static void spi_send(u8 b) {
    SPI0.DATA = b;
    while (!(SPI0.STATUS & SPI_IF_bm)) {}
}

static void tft_cmd(u8 c) {
    TFT_DC_CMD();
    spi_send(c);
}

static void tft_data(u8 d) {
    TFT_DC_DATA();
    spi_send(d);
}

void hal_init(void) {
    CPU_CCP = CCP_IOREG_gc;
    CLKCTRL.MCLKCTRLB = 0;

    PORTB.DIRCLR = PIN2_bm | PIN3_bm;
    PORTB.PIN2CTRL = PORT_PULLUPEN_bm;
    PORTB.PIN3CTRL = PORT_PULLUPEN_bm;

    TFT_CS_PORT.DIRSET  = (1 << TFT_CS_PIN);
    TFT_DC_PORT.DIRSET  = (1 << TFT_DC_PIN);
    TFT_RST_PORT.DIRSET = (1 << TFT_RST_PIN);
    SD_CS_PORT.DIRSET   = (1 << SD_CS_PIN);
    SD_CS_HIGH();

    PORTA.DIRSET = PIN1_bm | PIN3_bm;
    SPI0.CTRLA = SPI_MASTER_bm | SPI_PRESCALER_DIV4_gc | SPI_ENABLE_bm;

    PORTB.DIRSET = PIN2_bm;
    USART0.BAUD = (uint16_t)((F_CPU * 4ULL / (16UL * ZCOS_UART_BAUD)) + 0.5);
    USART0.CTRLB = USART_TXEN_bm;
}

/* =========================================================
 * SPI Storage Tier Implementation
 * ========================================================= */
void hal_spi_init(void) {
    SD_CS_HIGH();
}

void hal_spi_read_block(u32 address, u8 *dest, u16 len) {
    SD_CS_LOW();

    SPI0.DATA = 0x03;
    while (!(SPI0.STATUS & SPI_IF_bm)) {}
    SPI0.DATA = (u8)((uint32_t)address >> 16);
    while (!(SPI0.STATUS & SPI_IF_bm)) {}
    SPI0.DATA = (u8)(address >> 8);
    while (!(SPI0.STATUS & SPI_IF_bm)) {}
    SPI0.DATA = (u8)(address);
    while (!(SPI0.STATUS & SPI_IF_bm)) {}

    for (u16 i = 0; i < len; i++) {
        SPI0.DATA = 0xFF;
        while (!(SPI0.STATUS & SPI_IF_bm)) {}
        dest[i] = SPI0.DATA;
    }

    SD_CS_HIGH();
}

/* =========================================================
 * Display Functions (1-bit Monochrome)
 * ========================================================= */
void hal_disp_init(void) {
    TFT_CS_HIGH();
    TFT_RST_LOW();  hal_delay_ms(10u);
    TFT_RST_HIGH(); hal_delay_ms(50u);

    TFT_CS_LOW();
    tft_cmd(0xAE);
    tft_cmd(0xD5); tft_data(0x80);
    tft_cmd(0xA8); tft_data(ZCOS_DISP_H - 1);
    tft_cmd(0xAF);
    TFT_CS_HIGH();

    hal_disp_fill(COL_BLACK);
}

void hal_disp_fill(u8 color) {
    u8 fill_byte = (color ? 0xFF : 0x00);
    TFT_CS_LOW();
    u16 total_bytes = (ZCOS_DISP_W * ZCOS_DISP_H) / 8u;
    while (total_bytes--) {
        tft_data(fill_byte);
    }
    TFT_CS_HIGH();
}

void hal_disp_pixel(u16 x, u16 y, u8 c) {
    if (x >= ZCOS_DISP_W || y >= ZCOS_DISP_H) return;
    TFT_CS_LOW();
    tft_cmd(0xB0 + (y / 8));
    tft_cmd(0x10 | (x >> 4));
    tft_cmd(0x00 | (x & 0x0F));
    tft_data(c ? 0x01 << (y % 8) : 0x00);
    TFT_CS_HIGH();
}

void hal_disp_rect(u16 x, u16 y, u16 w, u16 h, u8 c) {
    for (u16 dy = 0; dy < h; dy++) {
        for (u16 dx = 0; dx < w; dx++) {
            hal_disp_pixel(x + dx, y + dy, c);
        }
    }
}

void hal_disp_tile1bpp(u16 x, u16 y, const u8 *tile8, u8 fg, u8 bg) {
    TFT_CS_LOW();
    for (u8 row = 0; row < 8u; row++) {
        u8 bits = tile8[row];
        tft_cmd(0xB0 + ((y + row) / 8));
        tft_cmd(0x10 | ((x) >> 4));
        tft_cmd(0x00 | ((x) & 0x0F));
        TFT_DC_DATA();
        for (u8 col = 0; col < 8u; col++) {
            u8 pixel = (bits & (0x80u >> col)) ? fg : bg;
            spi_send(pixel ? 0xFF : 0x00);
        }
    }
    TFT_CS_HIGH();
}

void hal_disp_flush(void) {}

void hal_sound_init(void) {}
void hal_sound_tone(u32 freq_hz) { s_current_freq = freq_hz; }
void hal_sound_off(void) { s_current_freq = 0u; }

u8 hal_input_read(void) {
    u8 s = 0u;
    if (!(PORTB.IN & PIN2_bm)) s |= BTN_UP;
    if (!(PORTB.IN & PIN3_bm)) s |= BTN_DOWN;
    return s;
}

void hal_uart_putc(char c) {
    while (!(USART0.STATUS & USART_DREIF_bm)) {}
    USART0.TXDATAL = (u8)c;
}

void hal_uart_puts(const char *s) {
    while (*s) hal_uart_putc(*s++);
}

void hal_uart_puthex(u32 v) {
    hal_uart_puts("0x");
    for (s8 i = 28; i >= 0; i -= 4) {
        u8 n = (u8)((v >> i) & 0xFu);
        hal_uart_putc((char)(n < 10u ? '0' + (char)n : 'A' + (char)(n - 10u)));
    }
}

ZCOS_NORETURN void hal_reset(void) {
    for (;;) {}
}

#endif /* ZCOS_CHIP_ATTINY814 */