#!/usr/bin/env python3
"""
ZeroCOS APC sound filter.
Reads QEMU serial output, passes display bytes through to stdout,
intercepts BEEP APC sequences and plays audio on the host.

Usage: qemu ... | python3 tools/zcos_filter.py <audio_cmd> <audio_py>
  audio_cmd : "beep" or "python3"
  audio_py  : path to tools/zcos_audio.py
"""
import sys
import subprocess

audio_cmd = sys.argv[1]
audio_py  = sys.argv[2]

stdin  = sys.stdin.buffer
stdout = sys.stdout.buffer

def play_tone(freq, dur):
    if freq == 0 or dur == 0:
        return
    if audio_cmd == "beep":
        subprocess.Popen(
            ["beep", "-f", str(freq), "-l", str(dur)],
            stderr=subprocess.DEVNULL)
    else:
        subprocess.Popen(
            ["python3", audio_py, str(freq), str(dur)],
            stderr=subprocess.DEVNULL)

ESC    = 0x1B
APC    = ord("_")
BSLASH = ord("\\")

state   = 0
apc_buf = b""

while True:
    b = stdin.read(1)
    if not b:
        break
    byte = b[0]

    if state == 0:
        if byte == ESC:
            state = 1
        else:
            stdout.write(b)
            stdout.flush()

    elif state == 1:
        if byte == APC:          # ESC _ = APC open
            state   = 2
            apc_buf = b""
        else:                    # not APC — re-emit held ESC + this byte
            stdout.write(bytes([ESC]))
            stdout.write(b)
            stdout.flush()
            state = 0

    elif state == 2:
        if byte == ESC:          # possible APC close: ESC backslash
            nb = stdin.read(1)
            if nb and nb[0] == BSLASH:
                # Complete APC sequence — decode and dispatch
                cmd = apc_buf.decode("ascii", errors="ignore")
                if cmd.startswith("BEEP:"):
                    parts = cmd.split(":")
                    if len(parts) == 3:
                        try:
                            freq = int(parts[1])
                            dur  = int(parts[2])
                            if dur > 0:
                                play_tone(freq, dur)
                        except ValueError:
                            pass
                state   = 0
                apc_buf = b""
            else:
                # False alarm, keep accumulating
                apc_buf += bytes([ESC])
                if nb:
                    apc_buf += nb
        else:
            apc_buf += b
