#!/usr/bin/env python3
"""
ZeroCOS host audio player.
Generates a square wave and pipes it to aplay.

Usage: python3 tools/zcos_audio.py <freq_hz> <duration_ms>
"""
import sys
import subprocess

freq = int(sys.argv[1])
dur  = int(sys.argv[2])

if freq == 0 or dur == 0:
    sys.exit(0)

freq = max(50,  min(freq, 20000))
dur  = max(10,  min(dur,  2000))

RATE    = 22050
samples = int(RATE * dur / 1000)
period  = RATE / freq
raw     = bytearray(samples)

for i in range(samples):
    phase  = (i % int(period)) / period
    raw[i] = 200 if phase < 0.5 else 56   # unsigned 8-bit square wave

proc = subprocess.Popen(
    ["aplay", "-q", "-r", str(RATE), "-f", "U8", "-c", "1", "-t", "raw", "-"],
    stdin=subprocess.PIPE,
    stderr=subprocess.DEVNULL)
proc.stdin.write(bytes(raw))
proc.stdin.close()
proc.wait()
