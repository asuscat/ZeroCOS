# ZeroCOS — Bare-Metal RISC-V Gaming OS

A micro gaming OS targeting RISC-V, optimized first for the CH32V003 (2KB RAM, 16KB flash)
and scaling cleanly to larger RV32I/RV64I devices.

## Architecture
- Pure bare-metal: no RTOS, no OS, no malloc, no libc
- Language: C11 + hand-tuned RISC-V assembly hot paths
- Memory: static bump allocator, all game state pre-allocated
- Display: HAL-abstracted (SPI TFT on CH32V003, framebuffer on larger chips / QEMU)
- Sound: Hardware PWM square-wave audio, zero CPU overhead
- Input: GPIO polling (buttons/joystick) or UART for QEMU

## Target Tiers

| Tier | Chip            | RAM    | Flash  | Display            |
|------|-----------------|--------|--------|--------------------|
| 0    | CH32V003        | 2 KB   | 16 KB  | SPI TFT 128×128    |
| 1    | CH32V203/V303   | 20 KB  | 128 KB | SPI TFT 240×320    |
| 2    | GD32VF103       | 32 KB  | 128 KB | SPI TFT 320×240    |
| 3    | QEMU virt RV32  | 32 MB  | —      | VirtIO/framebuffer |

## Build

```sh
# CH32V003 (Tier 0)
make TIER=0

# QEMU RV32 (Tier 3 — for dev/testing)
make TIER=3 run
```

## Games Included
- Frogger (Tier 0+)
- Snake  (Tier 0+)
- Tetris (Tier 1+)
- Breakout (Tier 0+)

## Project Layout
```
zerocos/
  include/       — public headers
  src/           — kernel core (boot, scheduler-stub, bump alloc)
  hal/           — hardware abstraction layer implementations
  games/         — game modules
  linker/        — linker scripts per tier
  tools/         — host-side ROM packer
```
