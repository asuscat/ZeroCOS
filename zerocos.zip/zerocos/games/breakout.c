/* =========================================================
 * ZeroCOS — Breakout
 * Fixed-point physics (8 bits fractional), no FP.
 * ========================================================= */

#include "zcos_config.h"
#include "zcos_draw.h"
#include "zcos_input.h"
#include "zcos_game.h"
#include "zcos_hal.h"

#define BRK_BRICK_COLS  8u
#define BRK_BRICK_ROWS  5u
#define BRK_BRICK_W     ((ZCOS_DISP_W - 4u) / BRK_BRICK_COLS)
#define BRK_BRICK_H     6u
#define BRK_BRICK_TOP   10u

#define BRK_PAD_W       24u
#define BRK_PAD_H       4u
#define BRK_PAD_Y       (ZCOS_DISP_H - BRK_PAD_H - 4u)
#define BRK_PAD_SPEED   3u

#define BRK_BALL_R      3u
/* Fixed-point: velocity stored as 8.8 */
#define FP              256      /* 1.0 in fixed-point      */
#define FP_BALL_SPEED   (FP*2)  /* 2 px/tick               */

static const u16 brick_colors[BRK_BRICK_ROWS] = {
    0xF800u,  /* Red    */
    0xFC00u,  /* Orange */
    0xFFE0u,  /* Yellow */
    0x07E0u,  /* Green  */
    0x001Fu,  /* Blue   */
};

static struct {
    u8  bricks[BRK_BRICK_ROWS][BRK_BRICK_COLS];
    s16 pad_x;
    s32 ball_x, ball_y;   /* 8.8 fixed point             */
    s32 ball_vx, ball_vy;
    u8  lives;
    u16 score;
    u8  launched;
    u8  dead;
} BRK;

static void brk_init(void) {
    for (u8 r = 0; r < BRK_BRICK_ROWS; r++)
        for (u8 c = 0; c < BRK_BRICK_COLS; c++)
            BRK.bricks[r][c] = 1u;
    BRK.pad_x    = (ZCOS_DISP_W - BRK_PAD_W) / 2;
    BRK.ball_x   = (ZCOS_DISP_W / 2) * FP;
    BRK.ball_y   = (BRK_PAD_Y - BRK_BALL_R - 1) * FP;
    BRK.ball_vx  = FP_BALL_SPEED;
    BRK.ball_vy  = -FP_BALL_SPEED;
    BRK.lives    = 3u;
    BRK.score    = 0u;
    BRK.launched = 0u;
    BRK.dead     = 0u;
}

static void brk_update(ZcosInput *inp) {
    if (BRK.dead) {
        if (INP_PRESSED(inp, BTN_A)) brk_init();
        return;
    }

    /* Paddle movement */
    if (INP_HELD(inp, BTN_LEFT) && BRK.pad_x > 0)
        BRK.pad_x -= BRK_PAD_SPEED;
    if (INP_HELD(inp, BTN_RIGHT) &&
        BRK.pad_x + BRK_PAD_W < ZCOS_DISP_W)
        BRK.pad_x += BRK_PAD_SPEED;

    if (!BRK.launched) {
        /* Ball sticks to paddle before launch */
        BRK.ball_x = (BRK.pad_x + BRK_PAD_W/2) * FP;
        if (INP_PRESSED(inp, BTN_A)) {
            BRK.launched = 1u;
            hal_sound_tone(440u);
            hal_delay_ms(30u);
            hal_sound_off();
        }
        return;
    }

    /* Move ball */
    BRK.ball_x += BRK.ball_vx;
    BRK.ball_y += BRK.ball_vy;

    s16 bx = (s16)(BRK.ball_x / FP);
    s16 by = (s16)(BRK.ball_y / FP);

    /* Wall bounce */
    if (bx <= BRK_BALL_R) {
        BRK.ball_vx = (BRK.ball_vx < 0) ? -BRK.ball_vx : BRK.ball_vx;
        hal_sound_tone(330u); hal_delay_ms(10u); hal_sound_off();
    }
    if (bx >= ZCOS_DISP_W - BRK_BALL_R) {
        BRK.ball_vx = (BRK.ball_vx > 0) ? -BRK.ball_vx : BRK.ball_vx;
        hal_sound_tone(330u); hal_delay_ms(10u); hal_sound_off();
    }
    if (by <= BRK_BALL_R) {
        BRK.ball_vy = (BRK.ball_vy < 0) ? -BRK.ball_vy : BRK.ball_vy;
        hal_sound_tone(330u); hal_delay_ms(10u); hal_sound_off();
    }

    /* Ball lost */
    if (by > ZCOS_DISP_H + BRK_BALL_R) {
        BRK.lives--;
        if (!BRK.lives) { BRK.dead = 1u; return; }
        BRK.launched = 0u;
        BRK.ball_y   = (BRK_PAD_Y - BRK_BALL_R - 2) * FP;
        hal_sound_tone(110u); hal_delay_ms(200u); hal_sound_off();
        return;
    }

    /* Paddle collision */
    if (by + BRK_BALL_R >= BRK_PAD_Y &&
        by - BRK_BALL_R <= BRK_PAD_Y + BRK_PAD_H &&
        bx >= BRK.pad_x && bx <= BRK.pad_x + BRK_PAD_W) {
        BRK.ball_vy = (BRK.ball_vy > 0) ? -BRK.ball_vy : BRK.ball_vy;
        /* Angle adjustment based on hit position */
        s16 offset = bx - (BRK.pad_x + BRK_PAD_W/2);
        BRK.ball_vx += offset * FP / (BRK_PAD_W);
        /* Clamp velocity */
        if (BRK.ball_vx > FP*4)  BRK.ball_vx = FP*4;
        if (BRK.ball_vx < -FP*4) BRK.ball_vx = -FP*4;
        hal_sound_tone(660u); hal_delay_ms(10u); hal_sound_off();
    }

    /* Brick collision */
    for (u8 r = 0; r < BRK_BRICK_ROWS; r++) {
        for (u8 c = 0; c < BRK_BRICK_COLS; c++) {
            if (!BRK.bricks[r][c]) continue;
            s16 bk_x = (s16)(2 + c * BRK_BRICK_W);
            s16 bk_y = (s16)(BRK_BRICK_TOP + r * (BRK_BRICK_H+1));
            if (bx + BRK_BALL_R >= bk_x &&
                bx - BRK_BALL_R <= bk_x + BRK_BRICK_W &&
                by + BRK_BALL_R >= bk_y &&
                by - BRK_BALL_R <= bk_y + BRK_BRICK_H) {
                BRK.bricks[r][c] = 0u;
                BRK.ball_vy = -BRK.ball_vy;
                BRK.score += (u16)(10u * (BRK_BRICK_ROWS - r));
                hal_sound_tone((u32)(880u + r*200u));
                hal_delay_ms(15u);
                hal_sound_off();
                goto done_brick;
            }
        }
    }
    done_brick:;
}

static void brk_draw(void) {
    draw_clear(COL_BLACK);

    /* Bricks */
    for (u8 r = 0; r < BRK_BRICK_ROWS; r++) {
        for (u8 c = 0; c < BRK_BRICK_COLS; c++) {
            if (!BRK.bricks[r][c]) continue;
            draw_rect((u16)(2u + c*BRK_BRICK_W),
                      (u16)(BRK_BRICK_TOP + r*(BRK_BRICK_H+1u)),
                      BRK_BRICK_W-1u, BRK_BRICK_H,
                      brick_colors[r]);
        }
    }

    /* Paddle */
    draw_rect((u16)BRK.pad_x, BRK_PAD_Y,
              BRK_PAD_W, BRK_PAD_H, COL_WHITE);

    /* Ball */
    s16 bx = (s16)(BRK.ball_x / FP);
    s16 by = (s16)(BRK.ball_y / FP);
    draw_rect((u16)(bx - BRK_BALL_R), (u16)(by - BRK_BALL_R),
              BRK_BALL_R*2u, BRK_BALL_R*2u, COL_CYAN);

    /* HUD */
    draw_int(0u, 1u, (s32)BRK.score, COL_YELLOW, COL_BLACK);
    for (u8 l = 0; l < BRK.lives && l < 5u; l++)
        draw_rect((u16)(ZCOS_DISP_W - 7u - l*7u), 1u,
                  5u, 5u, COL_CYAN);

    if (BRK.dead) {
        draw_rect(10u, ZCOS_DISP_H/2u - 8u,
                  (u16)(ZCOS_DISP_W-20u), 16u, COL_BLACK);
        draw_str(14u, ZCOS_DISP_H/2u - 4u,
                 "GAME OVER A=retry", COL_RED, COL_BLACK);
    }
}

const ZcosGame game_breakout = {
    .name     = "Breakout",
    .init     = brk_init,
    .update   = brk_update,
    .draw     = brk_draw,
    .shutdown = (void*)0,
};
