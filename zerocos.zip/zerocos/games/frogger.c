/* =========================================================
 * ZeroCOS — Frogger (50-byte RAM edition, 1-bit Binary Version)
 *
 * TOTAL RAM: 28 bytes of game state + ~20 bytes stack = 48 bytes
 *
 * Tricks used:
 *    - All positions stored as u8 tile coords (not pixels)
 *    - Car/log direction packed into sign of s8 col delta
 *    - Goals as 4-bit bitmask in one byte
 *    - Score capped at u8 (0-255)
 *    - No structs — parallel arrays (cheaper on RV32EC)
 *    - Frame throttle via single frame counter byte
 *    - All sprite/color data in flash (.rodata), zero RAM cost
 * ========================================================= */

#include "zcos_config.h"
#include "zcos_draw.h"
#include "zcos_input.h"
#include "zcos_game.h"
#include "zcos_hal.h"

/* ---- Grid --------------------------------------------- */
#define TILE    8u
#define COLS   16u
#define ROWS   16u

/* ---- Timing ------------------------------------------- */
#define CAR_EVERY   5u   /* cars move 1 tile every N frames  */
#define LOG_EVERY   7u   /* logs move 1 tile every N frames  */

/* ---- Layout ------------------------------------------- */
#define FROG_HOME_C  8u
#define FROG_HOME_R 15u
#define LIVES_START  3u

/* =========================================================
 *  ALL GAME STATE — 28 bytes total
 * ========================================================= */

/* Frog: 2 bytes */
static u8 fx, fy;

/* Score / lives / frame / dead timer / goals: 5 bytes */
static u8 sc, lv, fr, dt, gl; /* gl = goal bitmask bits 0-3 */

/* 4 cars: col(s8) + row(u8) + dir(s8 packed as +1/-1): 12 bytes */
static s8 car_c[4];
static u8 car_r[4];
static s8 car_d[4];  /* +1=right -1=left */

/* 3 logs: col + dir: 9 bytes (row is fixed: 3,4,5) */
static s8 log_c[3];
static s8 log_d[3]; /* +1=right -1=left */

/* TOTAL: 2+5+4+4+4+3+3 = 25 bytes + compiler alignment = ≤28 */

/* =========================================================
 *  Flash data (zero RAM cost)
 * ========================================================= */
static const u8 spr_frog[8] = {
    0b00111100,0b01111110,0b10011001,0b11111111,
    0b01111110,0b00100100,0b01000010,0b10000001
};
static const u8 spr_car[8] = {
    0b00000000,0b00111100,0b01111110,0b11111111,
    0b11111111,0b01111110,0b00111100,0b00000000
};
static const u8 spr_skull[8] = {
    0b00111100,0b01111110,0b11011011,0b11111111,
    0b01011010,0b00111100,0b00100100,0b00000000
};

/* =========================================================
 *  Init
 * ========================================================= */
static void frogger_init(void) {
    fx = FROG_HOME_C; fy = FROG_HOME_R;
    sc = 0u; lv = LIVES_START;
    fr = 0u; dt = 0u; gl = 0u;

    /* Cars on rows 9,10,11,9 — alternating direction */
    car_r[0]=9u;  car_c[0]=0;  car_d[0]= 1;
    car_r[1]=10u; car_c[1]=8;  car_d[1]=-1;
    car_r[2]=11u; car_c[2]=4;  car_d[2]= 1;
    car_r[3]=9u;  car_c[3]=12; car_d[3]=-1;

    /* Logs on rows 3,4,5 */
    log_c[0]=0;  log_d[0]= 1;
    log_c[1]=6;  log_d[1]=-1;
    log_c[2]=11; log_d[2]= 1;
}

/* =========================================================
 *  Update
 * ========================================================= */
static void frogger_update(ZcosInput *inp) {
    fr++;

    /* Dead animation */
    if (dt) {
        dt--;
        if (!dt) {
            if (!lv) { frogger_init(); return; }
            fx = FROG_HOME_C; fy = FROG_HOME_R;
        }
        return;
    }

    /* Input */
    if (INP_PRESSED(inp,BTN_UP)    && fy > 0u)
        { fy--; sc++; hal_sound_tone(880u); hal_delay_ms(25u); hal_sound_off(); }
    if (INP_PRESSED(inp,BTN_DOWN)  && fy < ROWS-1u)  fy++;
    if (INP_PRESSED(inp,BTN_LEFT)  && fx > 0u)
        { fx--; hal_sound_tone(440u); hal_delay_ms(20u); hal_sound_off(); }
    if (INP_PRESSED(inp,BTN_RIGHT) && fx < COLS-1u)
        { fx++; hal_sound_tone(440u); hal_delay_ms(20u); hal_sound_off(); }

    /* Move cars every CAR_EVERY frames */
    if (!(fr % CAR_EVERY)) {
        for (u8 i = 0u; i < 4u; i++) {
            car_c[i] = (s8)((car_c[i] + car_d[i] + (s8)COLS) % (s8)COLS);
        }
    }

    /* Move logs every LOG_EVERY frames */
    if (!(fr % LOG_EVERY)) {
        for (u8 i = 0u; i < 3u; i++) {
            log_c[i] = (s8)((log_c[i] + log_d[i] + (s8)COLS) % (s8)COLS);
        }
    }

    /* Car collision */
    for (u8 i = 0u; i < 4u; i++) {
        if (car_r[i] == fy && (u8)car_c[i] == fx) {
            lv--; dt = 30u;
            hal_sound_tone(110u); hal_delay_ms(120u); hal_sound_off();
            return;
        }
    }

    /* Water zone (rows 3-5): must be on a log */
    if (fy >= 3u && fy <= 5u) {
        u8 on = 0u;
        u8 log_row[3] = {3u,4u,5u};
        for (u8 i = 0u; i < 3u; i++) {
            if (log_row[i] != fy) continue;
            u8 lc0 = (u8)log_c[i];
            u8 lc1 = (u8)((log_c[i]+1+(s8)COLS) % (s8)COLS);
            if (lc0 == fx || lc1 == fx) { on = 1u; break; }
        }
        if (!on) {
            lv--; dt = 30u;
            hal_sound_tone(220u); hal_delay_ms(120u); hal_sound_off();
            return;
        }
    }

    /* Goal zone (row 0) */
    if (fy == 0u) {
        u8 slot = (u8)(fx / (COLS/4u));
        if (slot < 4u && !(gl & (1u<<slot))) {
            gl |= (1u<<slot);
            sc = (u8)(sc < 200u ? sc + 50u : 255u);
            hal_sound_tone(1760u); hal_delay_ms(150u); hal_sound_off();
        }
        fx = FROG_HOME_C; fy = FROG_HOME_R;
    }
}

/* =========================================================
 *  Draw
 * ========================================================= */
static void frogger_draw(void) {
    /* Clear screen to black */
    draw_clear(COL_BLACK);

    /* Safe zones and water/roads rendered via hollow/outline boxes or filled blocks */
    for (u8 r=3u; r<=5u; r++)
        draw_rect(0u,(u16)(r*TILE),(u16)(COLS*TILE),TILE,COL_WHITE);
    for (u8 r=9u; r<=11u; r++)
        draw_rect(0u,(u16)(r*TILE),(u16)(COLS*TILE),TILE,COL_WHITE);

    /* Goals */
    for (u8 i=0u; i<4u; i++) {
        u16 gx=(u16)(i*(COLS/4u)*TILE);
        draw_rect(gx,0u,(u16)(TILE-1u),(u16)(TILE-1u),
                  (gl&(1u<<i)) ? COL_BLACK : COL_WHITE);
    }

    /* Logs (2 tiles wide) */
    u8 log_row[3]={3u,4u,5u};
    for (u8 i=0u; i<3u; i++) {
        u16 ly=(u16)(log_row[i]*TILE);
        draw_rect((u16)((u8)log_c[i]*TILE),ly,TILE,TILE,COL_BLACK);
        draw_rect((u16)(((u8)log_c[i]+1u)%COLS*TILE),ly,TILE,TILE,COL_BLACK);
    }

    /* Cars */
    for (u8 i=0u; i<4u; i++)
        draw_sprite8((u16)((u8)car_c[i]*TILE),(u16)(car_r[i]*TILE),
                     spr_car,COL_WHITE,COL_BLACK);

    /* Frog or skull */
    u16 fpx=(u16)(fx*TILE), fpy=(u16)(fy*TILE);
    if (dt)
        draw_sprite8(fpx,fpy,spr_skull,COL_WHITE,COL_BLACK);
    else
        draw_sprite8(fpx,fpy,spr_frog,COL_WHITE,COL_BLACK);

    /* HUD */
    draw_int(0u,(u16)(ZCOS_DISP_H-8u),(s32)sc,COL_WHITE,COL_BLACK);
    for (u8 l=0u; l<lv&&l<5u; l++)
        draw_rect((u16)(ZCOS_DISP_W-7u-l*7u),(u16)(ZCOS_DISP_H-7u),
                  5u,5u,COL_WHITE);

    /* Win check — all 4 goals */
    if (gl == 0x0Fu) {
        draw_rect(10u,50u,(u16)(ZCOS_DISP_W-20u),16u,COL_BLACK);
        draw_str(14u,54u,"YOU WIN!",COL_WHITE,COL_BLACK);
    }
}

const ZcosGame game_frogger = {
    "Frogger", frogger_init, frogger_update, frogger_draw, (void*)0
};