/* =========================================================
 * ZeroCOS — Tiny Arkanoid Port (1-bit Binary Monochrome Version)
 * ========================================================= */

#include "zcos_config.h"
#include "zcos_draw.h"
#include "zcos_input.h"
#include "zcos_game.h"
#include "zcos_hal.h"

#define ARK_COLS   16u
#define ARK_ROWS   16u
#define TILE_SZ    8u

#define MAX_ROWS   8u
#define MAX_COLS   12u

typedef struct {
    u8  level;
    u8  lives;
    u8  paddle_y;
    s16 ball_x, ball_y;
    s16 ball_dx, ball_dy;
    u8  launch;
    u8  frame;
    u8  rows;
    u8  cols;
    u8  block_sz;
    u8  blocks[MAX_ROWS][MAX_COLS];
} ArkanoidGame;

static ArkanoidGame A;

static void load_level(void) {
    /* Scale grid size and block density with level */
    A.rows = 4u + (A.level > 4u ? 4u : (u8)(A.level - 1u));
    A.cols = 6u + (A.level > 4u ? 6u : (u8)(A.level - 1u));
    if (A.rows > MAX_ROWS) A.rows = MAX_ROWS;
    if (A.cols > MAX_COLS) A.cols = MAX_COLS;

    /* Blocks become smaller over time/rounds (min size 3px) */
    if (A.level == 1u)        A.block_sz = 6u;
    else if (A.level == 2u) A.block_sz = 5u;
    else if (A.level == 3u) A.block_sz = 4u;
    else                    A.block_sz = 3u;

    A.launch = 0u;
    A.ball_x = 40u;
    A.ball_y = 60u;
    A.ball_dx = 1;
    A.ball_dy = -1;

    for (u8 r = 0; r < MAX_ROWS; r++) {
        for (u8 c = 0; c < MAX_COLS; c++) {
            if (r < A.rows && c < A.cols) {
                A.blocks[r][c] = (r < 2u) ? 2u : 1u;
            } else {
                A.blocks[r][c] = 0u;
            }
        }
    }
}

static void arkanoid_init(void) {
    A.level = 1u;
    A.lives = 3u;
    A.paddle_y = 6u;
    A.frame = 0u;
    load_level();
}

static void arkanoid_update(ZcosInput *inp) {
    A.frame++;

    if (INP_PRESSED(inp, BTN_UP) && A.paddle_y > 1u) {
        A.paddle_y--;
    } else if (INP_PRESSED(inp, BTN_DOWN) && A.paddle_y < ARK_ROWS - 4u) {
        A.paddle_y++;
    }

    if (!A.launch && INP_PRESSED(inp, BTN_A)) {
        A.launch = 1u;
        hal_sound_tone(500u);
        hal_delay_ms(20u);
        hal_sound_off();
    }

    if (!A.launch) {
        A.ball_x = 16u;
        A.ball_y = (s16)(A.paddle_y * TILE_SZ + 4u);
    } else {
        /* Speed increases each round (fewer frames skipped per movement tick) */
        u8 speed_tick = (A.level >= 4u) ? 1u : (5u - A.level);
        
        if (A.frame % speed_tick == 0u) {
            A.ball_x += A.ball_dx;
            A.ball_y += A.ball_dy;

            /* Wall Bounces */
            if (A.ball_x <= 4) { A.ball_dx = (s16)-A.ball_dx; }
            if (A.ball_x >= (s16)(ARK_COLS * TILE_SZ - 4)) { A.ball_dx = (s16)-A.ball_dx; }
            if (A.ball_y <= 4) { A.ball_dy = (s16)-A.ball_dy; }

            /* Paddle Collision */
            if (A.ball_x <= 12 && 
                A.ball_y >= (s16)(A.paddle_y * TILE_SZ) && 
                A.ball_y <= (s16)((A.paddle_y + 3u) * TILE_SZ)) {
                A.ball_dx = 1;
                A.ball_dy = -1;
                hal_sound_tone(800u);
                hal_delay_ms(15u);
                hal_sound_off();
            }

            /* Block Collisions & Win Check */
            u8 remaining_blocks = 0u;
            for (u8 r = 0; r < A.rows; r++) {
                for (u8 c = 0; c < A.cols; c++) {
                    if (A.blocks[r][c] > 0u) {
                        remaining_blocks++;
                        u16 bk_x = (u16)(65u + c * (A.block_sz + 1u));
                        u16 bk_y = (u16)(8u + r * (A.block_sz + 2u));
                        
                        if (A.ball_x + 3 >= (s16)bk_x && A.ball_x <= (s16)(bk_x + A.block_sz) &&
                            A.ball_y + 3 >= (s16)bk_y && A.ball_y <= (s16)(bk_y + A.block_sz)) {
                            
                            A.blocks[r][c] = 0u;
                            A.ball_dy = (s16)-A.ball_dy;
                            
                            hal_sound_tone(150u);
                            hal_delay_ms(10u);
                            hal_sound_off();
                        }
                    }
                }
            }

            /* Advance Level if all blocks cleared */
            if (remaining_blocks == 0u) {
                A.level++;
                load_level();
                hal_sound_tone(1200u);
                hal_delay_ms(100u);
                hal_sound_off();
                return;
            }

            /* Bottom Boundary (Lose Life) */
            if (A.ball_y >= (s16)(ARK_ROWS * TILE_SZ)) {
                if (A.lives > 0u) {
                    A.lives--;
                    A.launch = 0u;
                    A.ball_x = 16u;
                    A.ball_y = (s16)(A.paddle_y * TILE_SZ + 4u);
                    A.ball_dx = 1;
                    A.ball_dy = -1;
                }
            }
        }
    }
}

static void arkanoid_draw(void) {
    draw_clear(COL_BLACK);
    draw_rect_outline(0u, 0u, ARK_COLS * TILE_SZ, ARK_ROWS * TILE_SZ, COL_WHITE);
    draw_rect(4u, A.paddle_y * TILE_SZ, 3u, 20u, COL_WHITE);

    if (A.launch || (A.frame % 16u < 8u)) {
        draw_rect((u16)A.ball_x, (u16)A.ball_y, 3u, 3u, COL_WHITE);
    }

    /* Draw Dynamic Block Grid using solid/pattern distinction or solid white blocks */
    for (u8 r = 0; r < A.rows; r++) {
        for (u8 c = 0; c < A.cols; c++) {
            if (A.blocks[r][c] > 0u) {
                u16 bx = (u16)(65u + c * (A.block_sz + 1u));
                u16 by = (u16)(8u + r * (A.block_sz + 2u));
                /* Use alternating white/black patterns or solid white blocks for 1-bit clarity */
                draw_rect(bx, by, A.block_sz, A.block_sz, (r % 2u == 0u) ? COL_WHITE : COL_WHITE);
            }
        }
    }

    draw_int(0u, (ARK_ROWS * TILE_SZ) + 1u, (s32)A.level, COL_WHITE, COL_BLACK);
}

const ZcosGame game_arkanoid = {
    .name     = "Arkanoid",
    .init     = arkanoid_init,
    .update   = arkanoid_update,
    .draw     = arkanoid_draw,
    .shutdown = (void*)0,
};