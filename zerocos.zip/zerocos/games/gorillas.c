/* =========================================================
 * ZeroCOS — Gorillas
 * Two gorillas on buildings throwing bananas.
 * Player throws with A, adjusts angle with UP/DOWN,
 * adjusts power with LEFT/RIGHT.
 * AI gorilla throws back automatically.
 * ========================================================= */

#include "zcos_config.h"
#include "zcos_draw.h"
#include "zcos_input.h"
#include "zcos_game.h"
#include "zcos_hal.h"

#define NUM_BUILDINGS   6u
#define GORILLA_W       8u
#define GORILLA_H       8u
#define MIN_POWER       4u
#define MAX_POWER       20u

/* Building layout — stored in flash as const */
static const u8 bld_x[NUM_BUILDINGS] = { 2, 24, 48, 72, 96, 116 };
static const u8 bld_w[NUM_BUILDINGS] = { 18, 18, 18, 18, 18, 10 };
static const u8 bld_h[NUM_BUILDINGS] = { 40, 55, 35, 50, 45, 60 };

/* Gorilla sprite 1bpp 8x8 */
static const u8 spr_gorilla[8] = {
    0b01111110,
    0b11111111,
    0b10111101,
    0b11111111,
    0b01111110,
    0b00100100,
    0b01100110,
    0b11000011,
};
static const u8 spr_banana[8] = {
    0b00011000,
    0b00111100,
    0b01111000,
    0b01110000,
    0b00110000,
    0b00111100,
    0b00011100,
    0b00001000,
};

typedef struct {
    s16 x, y;       /* fixed-point *4 */
    s16 vx, vy;
    u8  alive;
} Banana;

static struct {
    u8     p_angle;    /* degrees 0-90 mapped to 0-9 */
    u8     p_power;
    u8     a_angle;
    u8     a_power;
    Banana pban, aban;
    u8     p_lives, a_lives;
    u8     frame;
    u8     ai_delay;
    u8     winner;
    u8     whose_turn; /* 0=player 1=AI */
    u8     anim_timer;
} GR;

static u32 s_rng2 = 77771u;
static u8 rng8b(u8 max) {
    s_rng2 = s_rng2 * 22695477u + 1u;
    return (u8)((s_rng2 >> 16) % max);
}

/* Get top-of-building Y for gorilla placement */
static u8 bld_top(u8 i) {
    return (u8)(ZCOS_DISP_H - bld_h[i]);
}

/* Player gorilla sits on building 0, AI on building 5 */
#define P_BLD  0u
#define A_BLD  5u

static void gorillas_init(void) {
    GR.p_angle  = 5u;
    GR.p_power  = 10u;
    GR.a_angle  = 5u;
    GR.a_power  = 10u;
    GR.pban.alive = 0u;
    GR.aban.alive = 0u;
    GR.p_lives  = 3u;
    GR.a_lives  = 3u;
    GR.frame    = 0u;
    GR.ai_delay = 80u;
    GR.winner   = 0u;
    GR.whose_turn = 0u;
    GR.anim_timer = 0u;
}

static void throw_banana(Banana *b, s16 gx, s16 gy,
                          u8 angle, u8 power, s8 dir) {
    /* angle 0-9 → 0-90 degrees (approx with lookup) */
    /* Use integer trig approximation */
    static const u8 cos_t[10] = {16,15,14,12,10, 8, 6, 4, 2, 0};
    static const u8 sin_t[10] = { 0, 3, 6, 8,10,12,14,15,16,16};
    b->x  = gx * 4;
    b->y  = gy * 4;
    b->vx = (s16)(dir * (s16)(power * cos_t[angle] / 16u));
    b->vy = (s16)(-(s16)(power * sin_t[angle] / 16u));
    b->alive = 1u;
}

static u8 hits_building(s16 rx, s16 ry) {
    for (u8 i = 0; i < NUM_BUILDINGS; i++) {
        if (rx >= bld_x[i] && rx <= bld_x[i] + bld_w[i] &&
            ry >= (s16)bld_top(i) && ry < (s16)ZCOS_DISP_H)
            return 1u;
    }
    return 0u;
}

static void gorillas_update(ZcosInput *inp) {
    if (GR.winner) {
        if (INP_PRESSED(inp, BTN_A)) gorillas_init();
        return;
    }
    GR.frame++;

    /* Player turn */
    if (GR.whose_turn == 0u && !GR.pban.alive) {
        if (INP_PRESSED(inp, BTN_UP)   && GR.p_angle < 9u) GR.p_angle++;
        if (INP_PRESSED(inp, BTN_DOWN) && GR.p_angle > 0u) GR.p_angle--;
        if (INP_PRESSED(inp, BTN_RIGHT)&& GR.p_power < MAX_POWER) GR.p_power++;
        if (INP_PRESSED(inp, BTN_LEFT) && GR.p_power > MIN_POWER) GR.p_power--;
        if (INP_PRESSED(inp, BTN_A)) {
            s16 gx = (s16)(bld_x[P_BLD] + bld_w[P_BLD]/2);
            s16 gy = (s16)(bld_top(P_BLD) - GORILLA_H);
            throw_banana(&GR.pban, gx, gy, GR.p_angle, GR.p_power, 1);
            hal_sound_tone(660u); hal_delay_ms(30u); hal_sound_off();
        }
    }

    /* AI turn */
    if (GR.whose_turn == 1u && !GR.aban.alive) {
        if (GR.ai_delay) { GR.ai_delay--; }
        else {
            GR.a_angle = (u8)(3u + rng8b(5u));
            GR.a_power = (u8)(8u + rng8b(8u));
            s16 gx = (s16)(bld_x[A_BLD] + bld_w[A_BLD]/2);
            s16 gy = (s16)(bld_top(A_BLD) - GORILLA_H);
            throw_banana(&GR.aban, gx, gy, GR.a_angle, GR.a_power, -1);
            hal_sound_tone(440u); hal_delay_ms(30u); hal_sound_off();
            GR.ai_delay = (u8)(60u + rng8b(60u));
        }
    }

    /* Update player banana */
    if (GR.pban.alive) {
        GR.pban.vy++;
        GR.pban.x += GR.pban.vx;
        GR.pban.y += GR.pban.vy;
        s16 rx = GR.pban.x / 4;
        s16 ry = GR.pban.y / 4;
        if (rx < 0 || rx >= (s16)ZCOS_DISP_W || ry >= (s16)ZCOS_DISP_H) {
            GR.pban.alive = 0u; GR.whose_turn = 1u;
        } else if (hits_building(rx, ry)) {
            GR.pban.alive = 0u; GR.whose_turn = 1u;
        } else {
            /* Hit AI gorilla? */
            s16 agx = bld_x[A_BLD] + bld_w[A_BLD]/2 - GORILLA_W/2;
            s16 agy = (s16)(bld_top(A_BLD) - GORILLA_H);
            if (rx >= agx && rx <= agx+GORILLA_W &&
                ry >= agy && ry <= agy+GORILLA_H) {
                GR.pban.alive = 0u;
                GR.a_lives--;
                GR.anim_timer = 30u;
                hal_sound_tone(880u); hal_delay_ms(150u); hal_sound_off();
                if (!GR.a_lives) GR.winner = 1u;
                else GR.whose_turn = 1u;
            }
        }
    }

    /* Update AI banana */
    if (GR.aban.alive) {
        GR.aban.vy++;
        GR.aban.x += GR.aban.vx;
        GR.aban.y += GR.aban.vy;
        s16 rx = GR.aban.x / 4;
        s16 ry = GR.aban.y / 4;
        if (rx < 0 || rx >= (s16)ZCOS_DISP_W || ry >= (s16)ZCOS_DISP_H) {
            GR.aban.alive = 0u; GR.whose_turn = 0u;
        } else if (hits_building(rx, ry)) {
            GR.aban.alive = 0u; GR.whose_turn = 0u;
        } else {
            /* Hit player gorilla? */
            s16 pgx = bld_x[P_BLD] + bld_w[P_BLD]/2 - GORILLA_W/2;
            s16 pgy = (s16)(bld_top(P_BLD) - GORILLA_H);
            if (rx >= pgx && rx <= pgx+GORILLA_W &&
                ry >= pgy && ry <= pgy+GORILLA_H) {
                GR.aban.alive = 0u;
                GR.p_lives--;
                GR.anim_timer = 30u;
                hal_sound_tone(220u); hal_delay_ms(150u); hal_sound_off();
                if (!GR.p_lives) GR.winner = 2u;
                else GR.whose_turn = 0u;
            }
        }
    }

    if (GR.anim_timer) GR.anim_timer--;
}

static void gorillas_draw(void) {
    /* Sky */
    draw_clear(rgb565(20, 20, 60));

    /* Buildings */
    static const u16 bld_colors[NUM_BUILDINGS] = {
        0x630Cu, 0x4208u, 0x7BCFu, 0x52AAu, 0x6B4Du, 0x39C7u
    };
    for (u8 i = 0; i < NUM_BUILDINGS; i++) {
        u8 ty = bld_top(i);
        draw_rect(bld_x[i], ty, bld_w[i],
                  (u16)(ZCOS_DISP_H - ty), bld_colors[i % 6u]);
        /* Windows */
        for (u8 wy = ty + 3u; wy < ZCOS_DISP_H - 4u; wy += 6u)
            for (u8 wx = bld_x[i]+2u; wx < bld_x[i]+bld_w[i]-2u; wx += 5u)
                draw_rect(wx, wy, 3u, 3u, COL_YELLOW);
    }

    /* Gorillas */
    u8 p_flash = (GR.anim_timer > 0u && GR.whose_turn == 1u);
    u8 a_flash = (GR.anim_timer > 0u && GR.whose_turn == 0u);
    s16 pgx = bld_x[P_BLD] + bld_w[P_BLD]/2 - GORILLA_W/2;
    s16 pgy = (s16)(bld_top(P_BLD) - GORILLA_H);
    s16 agx = bld_x[A_BLD] + bld_w[A_BLD]/2 - GORILLA_W/2;
    s16 agy = (s16)(bld_top(A_BLD) - GORILLA_H);

    if (!p_flash || (GR.frame % 4u < 2u))
        draw_sprite8((u16)pgx, (u16)pgy, spr_gorilla,
                     rgb565(200,180,100), bld_colors[P_BLD]);
    if (!a_flash || (GR.frame % 4u < 2u))
        draw_sprite8((u16)agx, (u16)agy, spr_gorilla,
                     rgb565(200,180,100), bld_colors[A_BLD % 6u]);

    /* Bananas */
    if (GR.pban.alive)
        draw_sprite8((u16)(GR.pban.x/4), (u16)(GR.pban.y/4),
                     spr_banana, COL_YELLOW, rgb565(20,20,60));
    if (GR.aban.alive)
        draw_sprite8((u16)(GR.aban.x/4), (u16)(GR.aban.y/4),
                     spr_banana, COL_YELLOW, rgb565(20,20,60));

    /* HUD */
    draw_str(0u, 0u, "A:", COL_WHITE, rgb565(20,20,60));
    draw_int(12u, 0u, GR.p_angle, COL_YELLOW, rgb565(20,20,60));
    draw_str(24u, 0u, "P:", COL_WHITE, rgb565(20,20,60));
    draw_int(36u, 0u, GR.p_power, COL_CYAN, rgb565(20,20,60));

    for (u8 i = 0; i < GR.p_lives; i++)
        draw_rect((u16)(i*7u), 8u, 5u, 5u, rgb565(200,180,100));
    for (u8 i = 0; i < GR.a_lives; i++)
        draw_rect((u16)(ZCOS_DISP_W - 6u - i*7u), 8u, 5u, 5u,
                  rgb565(200,180,100));

    /* Turn indicator */
    if (!GR.winner) {
        if (GR.whose_turn == 0u)
            draw_str(ZCOS_DISP_W/2u - 6u, 0u, "YOU", COL_GREEN, rgb565(20,20,60));
        else
            draw_str(ZCOS_DISP_W/2u - 6u, 0u, "AI", COL_RED, rgb565(20,20,60));
    }

    if (GR.winner) {
        draw_rect(10u, ZCOS_DISP_H/2u - 8u,
                  (u16)(ZCOS_DISP_W - 20u), 20u, COL_BLACK);
        if (GR.winner == 1u)
            draw_str(14u, ZCOS_DISP_H/2u - 4u, "YOU WIN!", COL_YELLOW, COL_BLACK);
        else
            draw_str(14u, ZCOS_DISP_H/2u - 4u, "AI WINS!", COL_RED, COL_BLACK);
        draw_str(14u, ZCOS_DISP_H/2u + 6u, "A=retry", COL_WHITE, COL_BLACK);
    }
}

const ZcosGame game_gorillas = {
    "Gorillas", gorillas_init, gorillas_update, gorillas_draw, (void*)0
};
