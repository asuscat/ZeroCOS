#include "zcos_game.h"

#ifdef __AVR__
#include <avr/pgmspace.h>
#else
#define PROGMEM
#endif

/* 
 * Define a metadata structure or use dummy/proxy pointers that your 
 * SPI HAL casts or reads to extract the SD sector offset and file size.
 */
typedef struct {
    const char *name;
    unsigned int sd_offset;
    unsigned int size;
} ZcosSpigameMetadata_t;

static const ZcosSpigameMetadata_t game_frogger = {
    .name = "Frogger",
    .sd_offset = 0x1000,
    .size = 4096
};

static const ZcosSpigameMetadata_t game_1942 = {
    .name = "1942",
    .sd_offset = 0x2000,
    .size = 8192
};

static const ZcosSpigameMetadata_t game_arkanoid = {
    .name = "Arkanoid",
    .sd_offset = 0x4000,
    .size = 4096
};

/* 
 * We cast these metadata pointers to (const ZcosGame *const) so they satisfy 
 * the external array declaration expected by main.c and your UI menu.
 */
const ZcosGame *const zcos_game_table[] PROGMEM = {
    (const ZcosGame *)&game_frogger,
    (const ZcosGame *)&game_1942,
    (const ZcosGame *)&game_arkanoid
};

const unsigned int zcos_game_count = sizeof(zcos_game_table) / sizeof(zcos_game_table[0]);