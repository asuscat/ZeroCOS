/* =========================================================
 * ZeroCOS — Game Registry
 * Add new games here. Order = menu order.
 * ========================================================= */

#include "zcos_game.h"

extern const ZcosGame game_frogger;
extern const ZcosGame game_1942;
extern const ZcosGame game_arkanoid;

const ZcosGame *const zcos_game_table[] = {
    &game_1942,
    &game_arkanoid,
    &game_frogger,
};

const u32 zcos_game_count =
    sizeof(zcos_game_table) / sizeof(zcos_game_table[0]);
