#include "zcos_config.h"
#include "zcos_hal.h"
#include "zcos_draw.h"

void draw_rect_outline(u16 x, u16 y, u16 w, u16 h, u8 c) {
    hal_disp_rect(x, y, w, 1u, c);          /* Top */
    hal_disp_rect(x, y + h - 1u, w, 1u, c);  /* Bottom */
    hal_disp_rect(x, y, 1u, h, c);          /* Left */
    hal_disp_rect(x + w - 1u, y, 1u, h, c);  /* Right */
}

/* ---- Ultra-compact 3x5 Font (Flash only, ~117 bytes) ---- */
static const u8 F[39][3] = {
    {0x00,0x00,0x00},
    {0x1F,0x11,0x1F},{0x00,0x1F,0x00},{0x1D,0x15,0x17},{0x15,0x15,0x1F},
    {0x07,0x04,0x1F},{0x17,0x15,0x1D},{0x1F,0x15,0x1D},{0x01,0x01,0x1F},
    {0x1F,0x15,0x1F},{0x17,0x15,0x1F},
    {0x1E,0x05,0x1E},{0x1F,0x15,0x0E},{0x1F,0x11,0x11},{0x1F,0x11,0x0E},
    {0x1F,0x15,0x11},{0x1F,0x05,0x01},{0x1F,0x15,0x1D},{0x1F,0x04,0x1F},
    {0x11,0x1F,0x11},{0x18,0x10,0x1F},{0x1F,0x04,0x1B},{0x1F,0x10,0x10},
    {0x1F,0x02,0x1F},{0x1F,0x06,0x1F},{0x0E,0x11,0x0E},{0x1F,0x05,0x02},
    {0x0E,0x19,0x1E},{0x1F,0x05,0x1A},{0x16,0x15,0x0D},{0x01,0x1F,0x01},
    {0x1F,0x10,0x1F},{0x0F,0x10,0x0F},{0x1F,0x08,0x1F},{0x1B,0x04,0x1B},
    {0x03,0x1C,0x03},{0x19,0x15,0x13},
    {0x00,0x0A,0x00},{0x04,0x04,0x04},
};

static u8 fi(char c) {
    if (c == ' ') return 0;
    if (c >= '0' && c <= '9') return (u8)(c - '0' + 1);
    if (c >= 'A' && c <= 'Z') return (u8)(c - 'A' + 11);
    if (c >= 'a' && c <= 'z') return (u8)(c - 'a' + 11);
    if (c == ':') return 37;
    if (c == '-') return 38;
    return 0;
}

void draw_char(u16 x, u16 y, char c, u8 fg, u8 bg) {
    (void)bg;
    const u8 *gl = F[fi(c)];
    for (u8 col = 0; col < 3; col++) {
        for (u8 row = 0; row < 5; row++) {
            u8 color = (gl[col] & (1u << row)) ? fg : COL_BLACK;
            hal_disp_pixel((u16)(x + col), (u16)(y + row), color);
        }
    }
}

void draw_str(u16 x, u16 y, const char *s, u8 fg, u8 bg) {
    while (*s) {
        draw_char(x, y, *s++, fg, bg);
        x += 4u; /* 3px character width + 1px spacing */
    }
}

void draw_int(u16 x, u16 y, s32 v, u8 fg, u8 bg) {
    char buf[12];
    char *p = &buf[11];
    *p = '\0';
    int neg = 0;
    if (v < 0) {
        neg = 1;
        v = -v;
    }
    if (v == 0) {
        *--p = '0';
    } else {
        while (v > 0) {
            *--p = (char)('0' + (v % 10));
            v /= 10;
        }
    }
    if (neg) {
        *--p = '-';
    }
    draw_str(x, y, p, fg, bg);
}