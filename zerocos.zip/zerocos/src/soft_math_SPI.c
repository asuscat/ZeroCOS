/*
 * ZeroCOS — Copyright (C) 2026 asuscat
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

__attribute__((used, externally_visible))
unsigned int __mulsi3(unsigned int a, unsigned int b) {
    unsigned int r = 0;
    while (b > 0u) {
        if (b & 1u) {
            r += a;
        }
        a <<= 1u;
        b >>= 1u;
    }
    return r;
}

__attribute__((used, externally_visible))
unsigned int __udivsi3(unsigned int n, unsigned int d) {
    if (d == 0u) return 0u;
    unsigned int q = 0u;
    unsigned int r = 0u;
    for (int i = 31; i >= 0; i--) {
        r = (r << 1u) | ((n >> (unsigned int)i) & 1u);
        if (r >= d) {
            r -= d;
            q |= (1u << (unsigned int)i);
        }
    }
    return q;
}

__attribute__((used, externally_visible))
unsigned int __umodsi3(unsigned int n, unsigned int d) {
    if (d == 0u) return 0u;
    unsigned int r = 0u;
    for (int i = 31; i >= 0; i--) {
        r = (r << 1u) | ((n >> (unsigned int)i) & 1u);
        if (r >= d) {
            r -= d;
        }
    }
    return r;
}

/* --- ADDED: Signed Division & Modulo Fallbacks for Tier 5 --- */

__attribute__((used, externally_visible))
int __divsi3(int n, int d) {
    int negative = 0;
    if (n < 0) { n = -n; negative = !negative; }
    if (d < 0) { d = -d; negative = !negative; }
    unsigned int q = __udivsi3((unsigned int)n, (unsigned int)d);
    return negative ? -(int)q : (int)q;
}

__attribute__((used, externally_visible))
int __modsi3(int n, int d) {
    int negative = (n < 0);
    unsigned int r = __umodsi3(n < 0 ? (unsigned int)-n : (unsigned int)n, 
                               d < 0 ? (unsigned int)-d : (unsigned int)d);
    return negative ? -(int)r : (int)r;
}