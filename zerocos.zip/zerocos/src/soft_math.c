/*
 * ZeroCOS — Copyright (C) 2026 asuscat
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

/* =========================================================
 * Software Math Library Fallback for CH32V003 (rv32ec)
 * ========================================================= */

__attribute__((used, externally_visible))
unsigned int __mulsi3(unsigned int a, unsigned int b) {
    unsigned int r = 0;
    while (b > 0u) {
        if (b & 1u) {
            r += a;
        }
        a <<= 1u;
        b >>= 1u;
    }
    return r;
}

__attribute__((used, externally_visible))
unsigned int __udivsi3(unsigned int n, unsigned int d) {
    if (d == 0u) return 0u;
    unsigned int q = 0u;
    unsigned int r = 0u;
    for (int i = 31; i >= 0; i--) {
        r = (r << 1u) | ((n >> (unsigned int)i) & 1u);
        if (r >= d) {
            r -= d;
            q |= (1u << (unsigned int)i);
        }
    }
    return q;
}

__attribute__((used, externally_visible))
unsigned int __umodsi3(unsigned int n, unsigned int d) {
    if (d == 0u) return 0u;
    unsigned int r = 0u;
    for (int i = 31; i >= 0; i--) {
        r = (r << 1u) | ((n >> (unsigned int)i) & 1u);
        if (r >= d) {
            r -= d;
        }
    }
    return r;
}