#!/bin/bash
# =========================================================
# ZeroCOS — QEMU launcher with host audio
#
# Intercepts APC BEEP escape sequences from QEMU serial
# and plays real pitched tones on the host.
#
# Audio backends (tries in order):
#   beep    — sudo apt install beep  (PC speaker, low latency)
#   python3 — uses aplay (ALSA), generates PCM square waves
#
# Usage:
#   ./run.sh [TIER]          default TIER=3
#   ./run.sh 3 --no-sound
#   make run TIER=3
# =========================================================

TIER=${1:-3}
NO_SOUND=0
[[ "$2" == "--no-sound" ]] && NO_SOUND=1

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
FILTER="$SCRIPT_DIR/tools/zcos_filter.py"
AUDIO="$SCRIPT_DIR/tools/zcos_audio.py"
ELF="$SCRIPT_DIR/zerocos_tier${TIER}.elf"

# ---- Detect audio backend --------------------------------
AUDIO_CMD=""

if [[ $NO_SOUND -eq 0 ]]; then
    if command -v beep &>/dev/null; then
        AUDIO_CMD="beep"
    elif [[ -x /usr/bin/python3 ]] && [[ -x /usr/bin/aplay ]]; then
        AUDIO_CMD="python3"
    fi

    if [[ -z "$AUDIO_CMD" ]]; then
        echo "[ZeroCOS] No audio backend found."
        echo "          Install 'beep':  sudo apt install beep"
        echo "          Or ensure 'aplay' is available (alsa-utils)"
        echo "[ZeroCOS] Running without sound."
    else
        echo "[ZeroCOS] Audio: $AUDIO_CMD"
    fi
fi

# ---- Build if .elf is missing ----------------------------
if [[ ! -f "$ELF" ]]; then
    echo "[ZeroCOS] Building TIER=$TIER..."
    make -C "$SCRIPT_DIR" TIER=$TIER || exit 1
fi

echo "[ZeroCOS] Launching TIER=$TIER"
echo "[ZeroCOS] Controls: WASD=move  Z=A  X=B  Enter=Start  Tab=Select"
echo ""

QEMU_ARGS=(
    qemu-system-riscv32
    -machine virt
    -bios none
    -nographic
    -monitor none
    -kernel "$ELF"
)

if [[ -n "$AUDIO_CMD" ]]; then
    "${QEMU_ARGS[@]}" | python3 "$FILTER" "$AUDIO_CMD" "$AUDIO"
else
    "${QEMU_ARGS[@]}"
fi
