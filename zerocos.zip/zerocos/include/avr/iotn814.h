/*
 * ZeroCOS — Copyright (C) 2026 asuscat
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

#ifndef AVR_IOTN814_H
#define AVR_IOTN814_H

#ifndef __AVR_ATtiny814__
#define __AVR_ATtiny814__
#endif

#include <stdint.h>

/* CPU / CCP / CLKCTRL */
#define CPU_CCP     (*(volatile uint8_t *)0x0034)
#define CCP_IOREG_gc 0xD8

typedef struct {
    volatile uint8_t MCLKCTRLA;
    volatile uint8_t MCLKCTRLB;
    volatile uint8_t MCLKSTATUS;
    volatile uint8_t OSCCMP;
    volatile uint8_t CLKOUT;
} CLKCTRL_t;
#define CLKCTRL (*(volatile CLKCTRL_t *)0x0080)

/* Ports */
typedef struct {
    volatile uint8_t DIR, DIRSET, DIRCLR, DIRTGL;
    volatile uint8_t OUT, OUTSET, OUTCLR, OUTTGL;
    volatile uint8_t IN, INTFLAGS;
    volatile uint8_t PIN0CTRL, PIN1CTRL, PIN2CTRL, PIN3CTRL;
    volatile uint8_t PIN4CTRL, PIN5CTRL, PIN6CTRL, PIN7CTRL;
} PORT_t;

#define PORTA   (*(volatile PORT_t *)0x0400)
#define PORTB   (*(volatile PORT_t *)0x0420)

#define PIN0_bm 0x01
#define PIN1_bm 0x02
#define PIN2_bm 0x04
#define PIN3_bm 0x08
#define PIN4_bm 0x10
#define PIN5_bm 0x20
#define PIN6_bm 0x40
#define PIN7_bm 0x80

#define PORT_PULLUPEN_bm 0x08

/* SPI0 */
typedef struct {
    volatile uint8_t CTRLA, CTRLB, INTCTRL, INTFLAGS, STATUS, ADDR, DATA;
} SPI_t;

#define SPI0            (*(volatile SPI_t *)0x0600)
#define SPI_MASTER_bm   0x01
#define SPI_ENABLE_bm   0x01
#define SPI_PRESCALER_DIV4_gc 0x00
#define SPI_IF_bm       0x80

/* USART0 */
typedef struct {
    volatile uint8_t RXDATAL, RXDATAH;
    volatile uint8_t TXDATAL, TXDATAH;
    volatile uint8_t STATUS, CTRLA, CTRLB, CTRLC;
    volatile uint16_t BAUD;
} USART_struct_t;

#define USART0          (*(volatile USART_struct_t *)0x0800)
#define USART_TXEN_bm   0x40
#define USART_DREIF_bm  0x20

#endif /* AVR_IOTN814_H */