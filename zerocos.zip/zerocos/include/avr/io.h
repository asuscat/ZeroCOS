#ifndef AVR_IO_H_INTERCEPT
#define AVR_IO_H_INTERCEPT

#if defined(ZCOS_CHIP_ATTINY814) || defined(__AVR_ATtiny814__)
#ifndef __AVR_ATtiny814__
#define __AVR_ATtiny814__ 1
#endif

/* Include local device definitions directly to bypass outdated system headers */
#include "avr/iotn814.h"

#else

#include_next <avr/io.h>

#endif

#endif /* AVR_IO_H_INTERCEPT */