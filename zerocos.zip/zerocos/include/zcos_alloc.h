/*
 * ZeroCOS — Copyright (C) 2026 asuscat
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

#ifndef ZCOS_ALLOC_H
#define ZCOS_ALLOC_H

#include "zcos_config.h"

/* =========================================================
 *  ZeroCOS Bump Allocator (Unified Architecture Router)
 * ========================================================= */

#if defined(ZCOS_ARCH_AVR) || defined(ZCOS_CHIP_ATTINY814)

/* ---------------------------------------------------------
 *  AVR Tier 4 — Ultra-Lean, Zero-Security, Minimal RAM
 *  - 16-bit pointers (u16), 2-byte alignment
 *  - ZERO bounds checks, ZERO safety branches
 * --------------------------------------------------------- */
extern u8 _zcos_heap[];
extern u16 _zcos_heap_ptr;

ZCOS_INLINE void *bump_alloc(u16 n) {
    n = (n + 1u) & ~1u; /* Fast 2-byte alignment */
    void *p = (void*)&_zcos_heap[_zcos_heap_ptr];
    _zcos_heap_ptr += n;
    return p;
}

ZCOS_INLINE void bump_reset(void) {
    _zcos_heap_ptr = 0u;
}

ZCOS_INLINE u16 bump_free(void) {
    return (u16)ZCOS_HEAP_SIZE - _zcos_heap_ptr;
}

#else

/* ---------------------------------------------------------
 *  RISC-V / 32-bit Tiers (0, 1, 2, 3)
 *  - 32-bit pointers (u32), 4-byte alignment
 * --------------------------------------------------------- */
extern u8  _zcos_heap[ZCOS_HEAP_SIZE];
extern u32 _zcos_heap_ptr;

ZCOS_INLINE void *bump_alloc(u32 n) {
    n = (n + 3u) & ~3u;
    if (_zcos_heap_ptr + n > ZCOS_HEAP_SIZE) return (void*)0;
    void *p = &_zcos_heap[_zcos_heap_ptr];
    _zcos_heap_ptr += n;
    return p;
}

ZCOS_INLINE void bump_reset(void) {
    _zcos_heap_ptr = 0u;
}

ZCOS_INLINE u32 bump_free(void) {
    return ZCOS_HEAP_SIZE - _zcos_heap_ptr;
}

#endif /* ZCOS_ARCH_AVR */

#endif /* ZCOS_ALLOC_H */