#ifndef ZCOS_DRAW_H
#define ZCOS_DRAW_H

#include "zcos_config.h"
#include "zcos_hal.h"

/* =========================================================
 * ZeroCOS Draw Library — 1-bit Monochrome Binary Optimized
 * Colors: 0 = off/black, 1 = on/white
 * ========================================================= */

/* Font declarations */
extern const u8 zcos_font5x7[95][5];

void draw_char(u16 x, u16 y, char c, u8 fg, u8 bg);
void draw_str(u16 x, u16 y, const char *s, u8 fg, u8 bg);
void draw_int(u16 x, u16 y, s32 v, u8 fg, u8 bg);

/* --- Sprite Blitter ------------------------------------- */
ZCOS_INLINE void draw_sprite8(u16 x, u16 y, const u8 *data8, u8 fg, u8 bg) {
    hal_disp_tile1bpp(x, y, data8, fg, bg);
}

/* --- Primitives ---------------------------------------- */
ZCOS_INLINE void draw_rect(u16 x, u16 y, u16 w, u16 h, u8 c) {
    hal_disp_rect(x, y, w, h, c);
}

void draw_rect_outline(u16 x, u16 y, u16 w, u16 h, u8 c);

ZCOS_INLINE void draw_hline(u16 x, u16 y, u16 len, u8 c) {
    hal_disp_rect(x, y, len, 1u, c);
}

ZCOS_INLINE void draw_vline(u16 x, u16 y, u16 len, u8 c) {
    hal_disp_rect(x, y, 1u, len, c);
}

/* --- Screen Helpers ------------------------------------ */
ZCOS_INLINE void draw_clear(u8 c) { hal_disp_fill(c); }
ZCOS_INLINE void draw_flush(void) { hal_disp_flush(); }

#endif /* ZCOS_DRAW_H */