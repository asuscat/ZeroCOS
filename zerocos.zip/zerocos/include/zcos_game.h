/*
 * ZeroCOS — Copyright (C) 2026 asuscat
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

#ifndef ZCOS_GAME_H
#define ZCOS_GAME_H

#include "zcos_config.h"
#include "zcos_input.h"

/* =========================================================
 *  ZeroCOS Game Module Interface
 *
 *  Each game is a static struct of function pointers.
 *  The kernel calls init once, then update+draw at TICK_HZ.
 * ========================================================= */

typedef struct ZcosGame {
    const char *name;               /* short display name   */
    void (*init)(void);             /* called on game start */
    void (*update)(ZcosInput *inp); /* game logic tick      */
    void (*draw)(void);             /* render this frame    */
    void (*shutdown)(void);         /* optional cleanup     */
} ZcosGame;

/* Game registry — populate in games/game_list.c */
extern const ZcosGame *const zcos_game_table[];
extern const u32 zcos_game_count;

#endif /* ZCOS_GAME_H */
