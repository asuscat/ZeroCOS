/*
 * ZeroCOS — Copyright (C) 2026 asuscat
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

#ifndef ZCOS_HAL_H
#define ZCOS_HAL_H

#include "zcos_config.h"

/* =========================================================
 * ZeroCOS Hardware Abstraction Layer — 1-bit Monochrome Optimized
 * ========================================================= */

void hal_volume_set(u8 vol);
int hal_volume_get(void);

/* ---- System -------------------------------------------- */
void hal_init(void);
void hal_delay_us(u32 us);
void hal_delay_ms(u32 ms);
u32 hal_tick_get(void);
ZCOS_NORETURN void hal_reset(void);

/* ---- Display (Strict 1-bit Binary Color) --------------- */
void hal_disp_init(void);
void hal_disp_fill(u8 color);
void hal_disp_pixel(u16 x, u16 y, u8 c);
void hal_disp_rect(u16 x, u16 y, u16 w, u16 h, u8 c);
void hal_disp_tile1bpp(u16 x, u16 y, const u8 *tile8, u8 fg, u8 bg);
void hal_disp_flush(void);

/* ---- Sound --------------------------------------------- */
void hal_sound_init(void);
void hal_sound_tone(u32 freq_hz);
void hal_sound_off(void);

/* ---- Input --------------------------------------------- */
u8 hal_input_read(void);

/* ---- UART (debug / QEMU console) ----------------------- */
void hal_uart_putc(char c);
void hal_uart_puts(const char *s);
void hal_uart_puthex(u32 v);

/* ---- Color System (1-bit Monochrome Binary) ------------ */
#define COL_BLACK       0u
#define COL_WHITE       1u

#endif /* ZCOS_HAL_H */