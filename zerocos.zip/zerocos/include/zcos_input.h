/*
 * ZeroCOS — Copyright (C) 2026 asuscat
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

#ifndef ZCOS_INPUT_H
#define ZCOS_INPUT_H

#include "zcos_config.h"
#include "zcos_hal.h"

#define BTN_UP      (1u << 0)
#define BTN_DOWN    (1u << 1)
#define BTN_LEFT    (1u << 2)
#define BTN_RIGHT   (1u << 3)
#define BTN_A       (1u << 4)
#define BTN_B       (1u << 5)
#define BTN_SELECT  (1u << 6)
#define BTN_START   (1u << 7)

typedef struct {
    u8 held;
    u8 pressed;
    u8 released;
    u8 _prev;
} ZcosInput;

ZCOS_INLINE void input_update(ZcosInput *i) {
    u8 c = hal_input_read();
    u8 p = i->_prev;
    i->pressed  = c & ~p;
    i->released = ~c & p;
    i->held     = c;
    i->_prev    = c;
}

#define INP_HELD(i, b)     ((i)->held     & (b))
#define INP_PRESSED(i, b)  ((i)->pressed  & (b))
#define INP_RELEASED(i, b) ((i)->released & (b))

#endif /* ZCOS_INPUT_H */