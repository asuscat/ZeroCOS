/*
 * ZeroCOS — Copyright (C) 2026 asuscat
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

/* =========================================================
 * ZeroCOS HAL — QEMU virt SPI Storage Tier (Tier 7, RV32IMAC)
 * ========================================================= */

#include "zcos_config.h"
#include "zcos_hal.h"
#include "zcos_input.h"

#if defined(ZCOS_CHIP_QEMU) && defined(ZCOS_SPI_STORAGE)

#define UART0_BASE  0x10000000u
#define UART0_RBR   (*(volatile u8*)(UART0_BASE + 0x00u))
#define UART0_THR   (*(volatile u8*)(UART0_BASE + 0x00u))
#define UART0_LSR   (*(volatile u8*)(UART0_BASE + 0x05u))

static u8 s_zcos_volume = 100u;

void hal_volume_set(u8 vol) { if (vol > 100u) vol = 100u; s_zcos_volume = vol; }
int hal_volume_get(void) { return (int)s_zcos_volume; }

static u32 s_px[ZCOS_DISP_W * ZCOS_DISP_H];

#define CELL_COLS  ZCOS_DISP_W
#define CELL_ROWS  (ZCOS_DISP_H / 2u)
#define CELL_COUNT (CELL_COLS * CELL_ROWS)

static u8 s_front[CELL_COUNT];
static u8 s_back [CELL_COUNT];

static void uart_raw(char c) { while (!(UART0_LSR & 0x20u)) {} UART0_THR = (u8)c; }
static void uart_str(const char *s) { while (*s) uart_raw(*s++); }
static void uart_u8dec(u8 v) {
    if (v >= 100u) uart_raw((char)('0' + v/100u));
    if (v >=  10u) uart_raw((char)('0' + (v/10u)%10u));
    uart_raw((char)('0' + v%10u));
}
static void uart_u32dec(u32 v) {
    if (!v) { uart_raw('0'); return; }
    char buf[10]; u8 i = 0;
    while (v) { buf[i++] = (char)('0' + v%10u); v /= 10u; }
    while (i--) uart_raw(buf[i]);
}

void hal_init(void) {
    for (u32 i = 0; i < ZCOS_DISP_W * ZCOS_DISP_H; i++) s_px[i] = 0u;
    for (u32 i = 0; i < CELL_COUNT; i++) s_front[i] = 0xFFu;
}

void hal_disp_init(void) {
    uart_str("\033[?25l\033[2J\033[H");
}

/* 1-bit color conversion: 0 = Black, anything else = White */
static u32 color_to_xrgb(u8 c) {
    return (c == 0u) ? 0x000000u : 0xFFFFFFu;
}

void hal_disp_fill(u8 color) {
    u32 px = color_to_xrgb(color);
    u32 n = ZCOS_DISP_W * ZCOS_DISP_H;
    for (u32 i = 0; i < n; i++) s_px[i] = px;
}

void hal_disp_pixel(u16 x, u16 y, u8 c) {
    if (x >= ZCOS_DISP_W || y >= ZCOS_DISP_H) return;
    s_px[(u32)y * ZCOS_DISP_W + x] = color_to_xrgb(c);
}

void hal_disp_rect(u16 x, u16 y, u16 w, u16 h, u8 c) {
    if (!w || !h) return;
    u16 x1 = x + w; if (x1 > ZCOS_DISP_W) x1 = ZCOS_DISP_W;
    u16 y1 = y + h; if (y1 > ZCOS_DISP_H) y1 = ZCOS_DISP_H;
    u32 px = color_to_xrgb(c);
    for (u16 row = y; row < y1; row++) {
        u32 *line = &s_px[(u32)row * ZCOS_DISP_W + x];
        for (u16 col = 0; col < (u16)(x1-x); col++) line[col] = px;
    }
}

void hal_disp_tile1bpp(u16 x, u16 y, const u8 *tile8, u8 fg, u8 bg) {
    u32 pfg = color_to_xrgb(fg), pbg = color_to_xrgb(bg);
    for (u8 row = 0; row < 8u; row++) {
        u8 bits = tile8[row];
        u32 *line = &s_px[((u32)y+row)*ZCOS_DISP_W + x];
        for (u8 col = 0; col < 8u; col++)
            line[col] = (bits & (0x80u >> col)) ? pfg : pbg;
    }
}

void hal_disp_flush(void) {
    /* Fast 1-bit vertical pairing into cell buffers (0 = Black, 1 = White) */
    for (u16 tr = 0; tr < CELL_ROWS; tr++) {
        for (u16 tc = 0; tc < CELL_COLS; tc++) {
            u32 top = s_px[(u32)(tr*2u) * ZCOS_DISP_W + tc];
            u32 bot = s_px[(u32)(tr*2u+1u) * ZCOS_DISP_W + tc];
            u8 ci_top = (top != 0u) ? 1u : 0u;
            u8 ci_bot = (bot != 0u) ? 1u : 0u;
            s_back[tr * CELL_COLS + tc] = (u8)((ci_top << 4) | ci_bot);
        }
    }

    u8 cur_fg = 0xFFu, cur_bg = 0xFFu;
    u16 cursor_row = 0xFFFFu, cursor_col = 0xFFFFu;

    for (u16 tr = 0; tr < CELL_ROWS; tr++) {
        for (u16 tc = 0; tc < CELL_COLS; tc++) {
            u32 idx = (u32)tr * CELL_COLS + tc;
            u8 cell = s_back[idx];
            if (cell == s_front[idx]) continue;

            u8 bg_idx = (u8)(cell >> 4), fg_idx = (u8)(cell & 0xFu);

            if (cursor_row != tr || cursor_col != tc) {
                uart_str("\033[");
                uart_u8dec((u8)(tr + 1u));
                uart_raw(';');
                uart_u8dec((u8)(tc + 1u));
                uart_raw('H');
                cursor_row = tr; cursor_col = tc;
            }

            if (fg_idx != cur_fg || bg_idx != cur_bg) {
                uart_str("\033[");
                /* ANSI standard black/white attributes */
                uart_str(fg_idx ? "97" : "30");
                uart_raw(';');
                uart_str(bg_idx ? "107" : "40");
                uart_raw('m');
                cur_fg = fg_idx; cur_bg = bg_idx;
            }

            uart_raw('\xe2'); uart_raw('\x96'); uart_raw('\x84');
            s_front[idx] = cell;
            cursor_col++;
            if (cursor_col >= CELL_COLS) cursor_col = 0xFFFFu;
        }
    }
    if (cur_fg != 0xFFu) uart_str("\033[0m");
}

/* =========================================================
 * Simulated SPI Storage (QEMU Virt Tier)
 * ========================================================= */
void hal_spi_init(void) {}

void hal_spi_read_block(u32 address, u8 *dest, u16 len) {
    volatile u8 *src_rom = (volatile u8*)(0x80800000u + address);
    for (u16 i = 0; i < len; i++) {
        dest[i] = src_rom[i];
    }
}

/* =========================================================
 * Sound & Input
 * ========================================================= */
static u32 s_last_freq = 0u;
static u32 s_tone_start_ms = 0u;

void hal_sound_init(void) { s_last_freq = 0u; s_tone_start_ms = 0u; }
void hal_sound_tone(u32 freq_hz) {
    if (!freq_hz || s_zcos_volume == 0u) { hal_sound_off(); return; }
    s_last_freq = freq_hz; s_tone_start_ms = hal_tick_get();
    uart_raw('\033'); uart_raw('_'); uart_str("BEEP:"); uart_u32dec(freq_hz); uart_str(":0"); uart_raw('\033'); uart_raw('\\');
}
void hal_sound_off(void) {
    if (!s_last_freq) return;
    u32 dur = hal_tick_get() - s_tone_start_ms; if (dur == 0u) dur = 1u;
    uart_raw('\033'); uart_raw('_'); uart_str("BEEP:"); uart_u32dec(s_last_freq); uart_raw(':'); uart_u32dec(dur); uart_raw('\033'); uart_raw('\\');
    s_last_freq = 0u;
}

static u8 s_btn_state = 0u;
static u32 s_btn_hold_ticks = 0u;

u8 hal_input_read(void) {
    u32 now = hal_tick_get();
    static u8 escape_state = 0;

    /* Drain all available bytes from UART FIFO */
    while (UART0_LSR & 0x01u) {
        u8 ch = UART0_RBR;
        s_btn_hold_ticks = now; /* Refresh hold timer on input activity */

        /* Parse ANSI escape sequences for terminal arrow keys (ESC [ A/B/C/D) */
        if (ch == '\033') {
            escape_state = 1;
            continue;
        } else if (escape_state == 1) {
            if (ch == '[') {
                escape_state = 2;
                continue;
            }
            escape_state = 0;
        } else if (escape_state == 2) {
            escape_state = 0;
            switch (ch) {
                case 'A': s_btn_state = BTN_UP;    return s_btn_state;
                case 'B': s_btn_state = BTN_DOWN;  return s_btn_state;
                case 'C': s_btn_state = BTN_RIGHT; return s_btn_state;
                case 'D': s_btn_state = BTN_LEFT;  return s_btn_state;
                default: break;
            }
        }

        /* Standard key mappings */
        switch (ch) {
            case 'w': case 'W': s_btn_state = BTN_UP;     break;
            case 's': case 'S': s_btn_state = BTN_DOWN;   break;
            case 'a': case 'A': s_btn_state = BTN_LEFT;   break;
            case 'd': case 'D': s_btn_state = BTN_RIGHT;  break;
            case 'z': case 'Z': s_btn_state = BTN_A;      break;
            case 'x': case 'X': s_btn_state = BTN_B;      break;
            case '\r': case '\n': s_btn_state = BTN_START;  break;
            case '\t':          s_btn_state = BTN_SELECT; break;
            default:            /* Ignore unknown chars */ break;
        }
    }

    /* Auto-release button state if no input received for 120ms */
    if ((now - s_btn_hold_ticks) > 120u) {
        s_btn_state = 0u;
    }

    return s_btn_state;
}

void hal_uart_putc(char c) { while (!(UART0_LSR & 0x20u)) {} UART0_THR = (u8)c; }
void hal_uart_puts(const char *s) { while (*s) hal_uart_putc(*s++); }
void hal_uart_puthex(u32 v) {
    hal_uart_puts("0x");
    for (s8 i = 28; i >= 0; i -= 4) {
        u8 nib = (u8)((v >> i) & 0xFu);
        hal_uart_putc(nib < 10u ? (char)('0' + nib) : (char)('A' + (nib - 10u)));
    }
}

/* --- Cycle-accurate hardware timing via RISC-V rdcycle instruction --- */
static inline u32 get_cpu_cycles(void) {
    u32 cycles;
    __asm__ volatile ("rdcycle %0" : "=r" (cycles));
    return cycles;
}

u32 hal_tick_get(void) {
    return get_cpu_cycles() / 10000u;
}

void hal_delay_us(u32 us) {
    u32 start = get_cpu_cycles();
    u32 target = us * 10u;
    while ((get_cpu_cycles() - start) < target) {}
}

void hal_delay_ms(u32 ms) {
    u32 start = get_cpu_cycles();
    u32 target = ms * 10000u;
    while ((get_cpu_cycles() - start) < target) {}
}

ZCOS_NORETURN void hal_reset(void) {
    uart_str("\r\n[RESET]\r\n");
    for (;;) {}
}

#endif /* ZCOS_CHIP_QEMU && ZCOS_SPI_STORAGE */