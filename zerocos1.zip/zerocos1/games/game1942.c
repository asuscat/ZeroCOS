/* =========================================================
 * ZeroCOS — 1942 (1-bit Binary Monochrome Version)
 * Vertical scrolling shooter. Player at bottom shoots up.
 * Enemies scroll down in formation. A=fire, directions=move.
 * ========================================================= */

#include "zcos_config.h"
#include "zcos_draw.h"
#include "zcos_input.h"
#include "zcos_game.h"
#include "zcos_hal.h"

#define MAX_ENEMIES     8u
#define MAX_BULLETS     4u
#define MAX_EBULLETS    4u
#define PLAYER_SPEED    2u
#define BULLET_SPEED    4u
#define EBULLET_SPEED   2u
#define ENEMY_W         8u
#define ENEMY_H         6u
#define PLAYER_W        8u
#define PLAYER_H        8u

/* Sprites 1bpp 8x8 */
static const u8 spr_player[8] = {
    0b00011000,
    0b00111100,
    0b01111110,
    0b11011011,
    0b11111111,
    0b00100100,
    0b01000010,
    0b00000000,
};
static const u8 spr_enemy[8] = {
    0b11000011,
    0b01111110,
    0b11111111,
    0b11011011,
    0b11111111,
    0b01111110,
    0b00100100,
    0b00000000,
};
static const u8 spr_explosion[8] = {
    0b01000010,
    0b00100100,
    0b10011001,
    0b01111110,
    0b01111110,
    0b10011001,
    0b00100100,
    0b01000010,
};

typedef struct { s16 x, y; u8 alive; } Entity;

static struct {
    s16     px, py;
    Entity  bullets[MAX_BULLETS];
    Entity  enemies[MAX_ENEMIES];
    Entity  ebullets[MAX_EBULLETS];
    u16     score;
    u8      lives;
    u8      frame;
    u8      fire_delay;
    u8      spawn_timer;
    u8      wave;
    u8      dead_timer;
    u8      game_over;
    u8      expl_x, expl_y, expl_timer;
} S;

static u32 s_rng3 = 55551u;
static u8 rng8c(u8 max) {
    s_rng3 = s_rng3 * 1664525u + 1013904223u;
    return (u8)((s_rng3 >> 16) % max);
}

static void game1942_init(void) {
    S.px = ZCOS_DISP_W / 2 - PLAYER_W/2;
    S.py = ZCOS_DISP_H - 20;
    S.score = 0u;
    S.lives = 3u;
    S.frame = 0u;
    S.fire_delay = 0u;
    S.spawn_timer = 30u;
    S.wave = 0u;
    S.dead_timer = 0u;
    S.game_over = 0u;
    S.expl_timer = 0u;
    for (u8 i = 0; i < MAX_BULLETS;  i++) S.bullets[i].alive  = 0u;
    for (u8 i = 0; i < MAX_ENEMIES;  i++) S.enemies[i].alive  = 0u;
    for (u8 i = 0; i < MAX_EBULLETS; i++) S.ebullets[i].alive = 0u;
}

static void spawn_wave(void) {
    u8 count = (u8)(3u + S.wave % 3u);
    if (count > MAX_ENEMIES) count = MAX_ENEMIES;
    u8 spacing = (u8)(ZCOS_DISP_W / (count + 1u));
    for (u8 i = 0; i < count; i++) {
        S.enemies[i].x = (s16)(spacing * (i+1u) - ENEMY_W/2);
        S.enemies[i].y = (s16)(-ENEMY_H - rng8c(20u));
        S.enemies[i].alive = 1u;
    }
    S.wave++;
}

static void game1942_update(ZcosInput *inp) {
    if (S.game_over) {
        if (INP_PRESSED(inp, BTN_A)) game1942_init();
        return;
    }

    S.frame++;

    if (S.dead_timer) {
        if (--S.dead_timer == 0u) {
            if (!S.lives) { S.game_over = 1u; return; }
            S.px = ZCOS_DISP_W/2 - PLAYER_W/2;
            S.py = ZCOS_DISP_H - 20;
            for (u8 i = 0; i < MAX_EBULLETS; i++) S.ebullets[i].alive = 0u;
        }
        return;
    }

    /* Player movement */
    if (INP_HELD(inp, BTN_LEFT)  && S.px > 0)
        S.px -= PLAYER_SPEED;
    if (INP_HELD(inp, BTN_RIGHT) && S.px < (s16)(ZCOS_DISP_W - PLAYER_W))
        S.px += PLAYER_SPEED;
    if (INP_HELD(inp, BTN_UP)    && S.py > (s16)(ZCOS_DISP_H/2))
        S.py -= PLAYER_SPEED;
    if (INP_HELD(inp, BTN_DOWN)  && S.py < (s16)(ZCOS_DISP_H - PLAYER_H - 2))
        S.py += PLAYER_SPEED;

    /* Fire */
    if (S.fire_delay) S.fire_delay--;
    if (INP_HELD(inp, BTN_A) && !S.fire_delay) {
        for (u8 i = 0; i < MAX_BULLETS; i++) {
            if (!S.bullets[i].alive) {
                S.bullets[i].x = S.px + PLAYER_W/2 - 1;
                S.bullets[i].y = S.py - 2;
                S.bullets[i].alive = 1u;
                S.fire_delay = 8u;
                hal_sound_tone(880u); hal_delay_ms(15u); hal_sound_off();
                break;
            }
        }
    }

    /* Move player bullets */
    for (u8 i = 0; i < MAX_BULLETS; i++) {
        if (!S.bullets[i].alive) continue;
        S.bullets[i].y -= BULLET_SPEED;
        if (S.bullets[i].y < 0) S.bullets[i].alive = 0u;
    }

    /* Move enemies */
    u8 all_dead = 1u;
    for (u8 i = 0; i < MAX_ENEMIES; i++) {
        if (!S.enemies[i].alive) continue;
        all_dead = 0u;
        S.enemies[i].y += 1u;
        /* Sine-wave horizontal movement */
        if (S.frame % 4u == 0u)
            S.enemies[i].x += (s16)((i % 2u) ? 1 : -1);
        /* Clamp */
        if (S.enemies[i].x < 0) S.enemies[i].x = 0;
        if (S.enemies[i].x > (s16)(ZCOS_DISP_W - ENEMY_W))
            S.enemies[i].x = (s16)(ZCOS_DISP_W - ENEMY_W);
        /* Off bottom */
        if (S.enemies[i].y > (s16)ZCOS_DISP_H) S.enemies[i].alive = 0u;
        /* Enemy fires randomly */
        if (S.frame % 60u == (u8)(i * 10u) && S.enemies[i].alive) {
            for (u8 j = 0; j < MAX_EBULLETS; j++) {
                if (!S.ebullets[j].alive) {
                    S.ebullets[j].x = S.enemies[i].x + ENEMY_W/2;
                    S.ebullets[j].y = S.enemies[i].y + ENEMY_H;
                    S.ebullets[j].alive = 1u;
                    break;
                }
            }
        }
    }
    if (all_dead) {
        if (S.spawn_timer) S.spawn_timer--;
        else { spawn_wave(); S.spawn_timer = 40u; }
    }

    /* Move enemy bullets */
    for (u8 i = 0; i < MAX_EBULLETS; i++) {
        if (!S.ebullets[i].alive) continue;
        S.ebullets[i].y += EBULLET_SPEED;
        if (S.ebullets[i].y > (s16)ZCOS_DISP_H) S.ebullets[i].alive = 0u;
    }

    /* Check player bullet vs enemy */
    for (u8 b = 0; b < MAX_BULLETS; b++) {
        if (!S.bullets[b].alive) continue;
        for (u8 e = 0; e < MAX_ENEMIES; e++) {
            if (!S.enemies[e].alive) continue;
            if (S.bullets[b].x >= S.enemies[e].x &&
                S.bullets[b].x <= S.enemies[e].x + ENEMY_W &&
                S.bullets[b].y >= S.enemies[e].y &&
                S.bullets[b].y <= S.enemies[e].y + ENEMY_H) {
                S.bullets[b].alive  = 0u;
                S.enemies[e].alive  = 0u;
                S.score += 10u;
                S.expl_x = (u8)(S.enemies[e].x);
                S.expl_y = (u8)(S.enemies[e].y);
                S.expl_timer = 8u;
                hal_sound_tone(660u); hal_delay_ms(20u); hal_sound_off();
            }
        }
    }

    /* Enemy bullet vs player */
    for (u8 i = 0; i < MAX_EBULLETS; i++) {
        if (!S.ebullets[i].alive) continue;
        if (S.ebullets[i].x >= S.px &&
            S.ebullets[i].x <= S.px + PLAYER_W &&
            S.ebullets[i].y >= S.py &&
            S.ebullets[i].y <= S.py + PLAYER_H) {
            S.ebullets[i].alive = 0u;
            S.lives--;
            S.dead_timer = 60u;
            S.expl_x = (u8)S.px; S.expl_y = (u8)S.py;
            S.expl_timer = 20u;
            hal_sound_tone(110u); hal_delay_ms(200u); hal_sound_off();
        }
    }

    if (S.expl_timer) S.expl_timer--;
}

static void game1942_draw(void) {
    /* Clear screen to black */
    draw_clear(COL_BLACK);

    /* Scrolling background lines */
    for (u16 y = 0; y < ZCOS_DISP_H; y += 8u) {
        u16 off = (S.frame / 2u + y) % ZCOS_DISP_W;
        draw_rect(off, y, 16u, 1u, COL_WHITE);
    }

    /* Player */
    if (!S.dead_timer)
        draw_sprite8((u16)S.px, (u16)S.py, spr_player,
                     COL_WHITE, COL_BLACK);

    /* Player bullets */
    for (u8 i = 0; i < MAX_BULLETS; i++)
        if (S.bullets[i].alive)
            draw_rect((u16)S.bullets[i].x, (u16)S.bullets[i].y,
                      2u, 4u, COL_WHITE);

    /* Enemies */
    for (u8 i = 0; i < MAX_ENEMIES; i++)
        if (S.enemies[i].alive)
            draw_sprite8((u16)S.enemies[i].x, (u16)S.enemies[i].y,
                         spr_enemy, COL_WHITE, COL_BLACK);

    /* Enemy bullets */
    for (u8 i = 0; i < MAX_EBULLETS; i++)
        if (S.ebullets[i].alive)
            draw_rect((u16)S.ebullets[i].x, (u16)S.ebullets[i].y,
                      2u, 4u, COL_WHITE);

    /* Explosion */
    if (S.expl_timer)
        draw_sprite8(S.expl_x, S.expl_y, spr_explosion,
                     COL_WHITE, COL_BLACK);

    /* HUD */
    draw_int(0u, 0u, (s32)S.score, COL_WHITE, COL_BLACK);
    for (u8 i = 0; i < S.lives && i < 5u; i++)
        draw_rect((u16)(ZCOS_DISP_W - 8u - i*8u), 1u, 6u, 6u, COL_WHITE);

    if (S.game_over) {
        draw_rect(10u, ZCOS_DISP_H/2u - 8u,
                  (u16)(ZCOS_DISP_W-20u), 20u, COL_BLACK);
        draw_str(14u, ZCOS_DISP_H/2u - 4u, "GAME OVER", COL_WHITE, COL_BLACK);
        draw_str(14u, ZCOS_DISP_H/2u + 6u, "A=retry",  COL_WHITE, COL_BLACK);
    }
}

const ZcosGame game_1942 = {
    "1942", game1942_init, game1942_update, game1942_draw, (void*)0
};

#if ZCOS_TIER == 5 || ZCOS_TIER == 6 || ZCOS_TIER == 7
void game_main(void) {
    game1942_init();
    ZcosInput inp = {0, 0, 0, 0};

    while (1) {
        // 1. Properly update inputs using the core input system
        input_update(&inp);

        // 2. Allow exiting back to the ZeroCOS menu via SELECT button
        if (INP_PRESSED(&inp, BTN_SELECT)) {
            break; // Safely exits the game loop and returns to the kernel menu!
        }

        // 3. Run game logic and draw
        game1942_update(&inp);
        game1942_draw();
        hal_disp_flush();

        hal_delay_ms(16); // ~60 FPS frame pacing
    }
}
#endif