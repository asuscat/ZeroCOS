/*
 * ZeroCOS — Copyright (C) 2026 asuscat
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

/* =========================================================
 * ZeroCOS — Non-SPI Kernel Main
 *
 * Responsibilities:
 *   1. Hardware init (via HAL)
 *   2. Show game selection menu (built-in game)
 *   3. Run selected game at ZCOS_TICK_HZ with fixed timestep
 *   4. Return to menu when game exits
 *   5. Pause menu with "main menu" and "Shut down" options
 *
 * No malloc, no RTOS, no libc.
 * ========================================================= */

#include "zcos_config.h"
#include "zcos_hal.h"
#include "zcos_draw.h"
#include "zcos_input.h"
#include "zcos_alloc.h"
#include "zcos_game.h"

/* Ensure NULL is defined in freestanding mode */
#ifndef NULL
#define NULL ((void*)0)
#endif

/* ---- Bump allocator storage (defined here, extern in .h) */
u8  _zcos_heap[ZCOS_HEAP_SIZE] ZCOS_ALIGNED(4);
#if defined(ZCOS_ARCH_AVR)
u16 _zcos_heap_ptr = 0u;
#else
u32 _zcos_heap_ptr = 0u;
#endif

/* ---- Built-in Game Entry Point ------------------------- */
extern void game_init(void);
extern void game_update(ZcosInput *inp);
extern void game_draw(void);

static const ZcosGame g_builtin_game = {
    "builtin",
    game_init,
    game_update,
    game_draw,
    NULL  /* Shutdown is optional / not required */
};

const ZcosGame *const zcos_game_table[] = {
    &g_builtin_game
};

const u32 zcos_game_count = 1;

/* ---- Trap handler (called from boot.S on exception) ----- */
void trap_handler(u32 cause, u32 epc) {
    hal_uart_puts("\r\n!TRAP cause=0x");
    hal_uart_puthex(cause);
    hal_uart_puts(" epc=0x");
    hal_uart_puthex(epc);
    hal_uart_puts("\r\n");
    for (;;) {}
}

/* ---- Hardware Shutdown Routine ------------------------- */
static void system_shutdown(void) {
#if defined(ZCOS_CHIP_CH32V003) || defined(ZCOS_CHIP_CH32V203)
    *(volatile u32*)(0x40013000u) = 0u; /* SPI1  */
    *(volatile u32*)(0x40012C00u) = 0u; /* TIM1  */
    *(volatile u32*)(0x40013800u + 0x0Cu) = 0u; /* USART1 */
    *(volatile u32*)(0x40010800u) = 0x44444444u; /* GPIOA */
    *(volatile u32*)(0x40011000u) = 0x44444444u; /* GPIOC */
    *(volatile u32*)(0x40011400u) = 0x44444444u; /* GPIOD */
    for(;;) __asm__ __volatile__("wfi");

#elif defined(ZCOS_ARCH_AVR)
    *(volatile u8*)(0x0A00u + 0x05u) = 0u;
    *(volatile u8*)(0x0A40u + 0x04u) = 0u;
    *(volatile u8*)(0x0400u + 0x04u) = 0x00u;
    *(volatile u8*)(0x0420u + 0x04u) = 0x00u;
    *(volatile u8*)(0x0050u) = 0x05u;
    for(;;) __asm__ __volatile__("sleep");

#else
    for(;;) {}
#endif
}

/* ---- Bare-bones In-Game Pause Menu (2 Options) --------- */
static u32 run_pause_menu(void) {
    u32 sel = 0;
    ZcosInput inp = {0, 0, 0, 0};
    u32 last_tick = hal_tick_get();

    const char *pause_options[2] = {
        "main menu",
        "Shut down"
    };

    for (;;) {
        u32 now = hal_tick_get();
        if ((now - last_tick) < (1000u / 30u))
            continue;
        last_tick = now;

        input_update(&inp);

        if (INP_PRESSED(&inp, BTN_UP)   && sel > 0)
            sel--;
        if (INP_PRESSED(&inp, BTN_DOWN) && sel + 1u < 2u)
            sel++;
        if (INP_PRESSED(&inp, BTN_A))
            return sel;

        draw_clear(COL_BLACK);

        for (u32 i = 0; i < 2u; i++) {
            u16 y  = (u16)(20u + i * 14u);
            u8  fg = (i == sel) ? COL_BLACK : COL_WHITE;
            u8  bg = (i == sel) ? COL_WHITE : COL_BLACK;
            if (i == sel)
                draw_rect(0, y, ZCOS_DISP_W, 11u, bg);
            draw_str(6u, (u16)(y + 2u), pause_options[i], fg, bg);
        }

        draw_str(2u, (u16)(ZCOS_DISP_H - 10u), "A=Select", COL_WHITE, COL_BLACK);
        hal_disp_flush();
    }
}

/* ---- Fixed-step game loop (Non-SPI Built-in) ----------- */
static void run_game(const ZcosGame *g) {
    ZcosInput inp = {0, 0, 0, 0};
    u32 last_tick = hal_tick_get();

    if (g->init) g->init();

    for (;;) {
        u32 now = hal_tick_get();
        if ((now - last_tick) < (1000u / ZCOS_TICK_HZ))
            continue;
        last_tick = now;

        input_update(&inp);

        /* SEL+START = exit to menu */
        if (INP_PRESSED(&inp, BTN_SELECT) &&
            INP_HELD(&inp, BTN_START))
            break;

        /* START = Open pause menu */
        if (INP_PRESSED(&inp, BTN_START)) {
            u32 choice = run_pause_menu();
            if (choice == 0u) {
                break;
            } else {
                system_shutdown();
            }
        }

        if (g->update) g->update(&inp);
        if (g->draw)   g->draw();

        hal_disp_flush();
    }

    if (g->shutdown) g->shutdown();
    bump_reset();
}

/* ---- Game selection menu ------------------------------- */
static u32 run_menu(void) {
    u32 sel = 0;
    ZcosInput inp = {0, 0, 0, 0};
    u32 last_tick = hal_tick_get();

    for (;;) {
        u32 now = hal_tick_get();
        if ((now - last_tick) < (1000u / 30u))
            continue;
        last_tick = now;

        input_update(&inp);

        if (INP_PRESSED(&inp, BTN_UP)   && sel > 0)
            sel--;
        if (INP_PRESSED(&inp, BTN_DOWN) && sel + 1u < zcos_game_count)
            sel++;
        if (INP_PRESSED(&inp, BTN_A))
            return sel;

        draw_clear(COL_BLACK);
        draw_hline(0, 12, ZCOS_DISP_W, COL_WHITE);

        for (u32 i = 0; i < zcos_game_count; i++) {
            u16 y  = (u16)(18u + i * 10u);
            u8  fg = (i == sel) ? COL_BLACK : COL_WHITE;
            u8  bg = (i == sel) ? COL_WHITE : COL_BLACK;
            if (i == sel)
                draw_rect(0, y, ZCOS_DISP_W, 9u, bg);
            
            draw_str(6u, (u16)(y + 1u), zcos_game_table[i]->name, fg, bg);
        }

        draw_str(2u, (u16)(ZCOS_DISP_H - 10u),
                 "A=Start SEL+STA=Menu", COL_WHITE, COL_BLACK);
        draw_flush();
        hal_disp_flush();
    }
}

/* ---- Entry point --------------------------------------- */
int main(void) {
    hal_init();
    hal_disp_init();
    hal_sound_init();

    for (;;) {
        u32 sel = run_menu();
        if (sel < zcos_game_count) {
            run_game(zcos_game_table[sel]);
        }
    }
}