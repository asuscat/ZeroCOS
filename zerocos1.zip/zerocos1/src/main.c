/*
 * ZeroCOS — Copyright (C) 2026 asuscat
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

/* =========================================================
 * ZeroCOS — Kernel main
 *
 * Responsibilities:
 *   1. Hardware init (via HAL)
 *   2. Show game selection menu (supports unlimited games via cartridges)
 *   3. Run selected game ROM from fixed cartridge slot (0x80400000)
 *   4. Return to menu when game exits
 *   5. TAB pause menu with "main menu" and "Shut down" options
 *
 * No malloc, no RTOS, no libc.
 * ========================================================= */

#include "zcos_config.h"
#include "zcos_hal.h"
#include "zcos_draw.h"
#include "zcos_input.h"
#include "zcos_alloc.h"
#include "game_list.h"

/* Ensure NULL is defined in freestanding mode */
#ifndef NULL
#define NULL ((void*)0)
#endif

/* ---- Bump allocator storage (defined here, extern in .h) */
u8  _zcos_heap[ZCOS_HEAP_SIZE] ZCOS_ALIGNED(4);
#if defined(ZCOS_ARCH_AVR)
u16 _zcos_heap_ptr = 0u;
#else
u32 _zcos_heap_ptr = 0u;
#endif

/* ---- Trap handler (called from boot.S on exception) ----- */
void trap_handler(u32 cause, u32 epc) {
    hal_uart_puts("\r\n!TRAP cause=0x");
    hal_uart_puthex(cause);
    hal_uart_puts(" epc=0x");
    hal_uart_puthex(epc);
    hal_uart_puts("\r\n");
    for (;;) {}
}

/* ---- Hardware Shutdown Routine ------------------------- */
__attribute__((unused)) static void system_shutdown(void) {
#if defined(ZCOS_CHIP_CH32V003) || defined(ZCOS_CHIP_CH32V203)
    /* Disable peripherals */
    *(volatile u32*)(0x40013000u) = 0u; /* SPI1  */
    *(volatile u32*)(0x40012C00u) = 0u; /* TIM1  */
    *(volatile u32*)(0x40013800u + 0x0Cu) = 0u; /* USART1 */
    /* Float all GPIO to stop current drain */
    *(volatile u32*)(0x40010800u) = 0x44444444u; /* GPIOA */
    *(volatile u32*)(0x40011000u) = 0x44444444u; /* GPIOC */
    *(volatile u32*)(0x40011400u) = 0x44444444u; /* GPIOD */
    /* Enter SLEEP mode via WFI — wakes on NRST button or power cycle */
    for(;;) __asm__ __volatile__("wfi");

#elif defined(ZCOS_ARCH_AVR)
    /* Disable TCA0 timer */
    *(volatile u8*)(0x0A00u + 0x05u) = 0u;
    /* Disable TCB0 timer */
    *(volatile u8*)(0x0A40u + 0x04u) = 0u;
    /* All ports to input, no pull-up (lowest leakage) */
    *(volatile u8*)(0x0400u + 0x04u) = 0x00u; /* PORTA.DIR = input */
    *(volatile u8*)(0x0420u + 0x04u) = 0x00u; /* PORTB.DIR = input */
    /* SLPCTRL: set SMODE=PDOWN (0x2), enable SE bit (0x1) = 0x05 */
    *(volatile u8*)(0x0050u) = 0x05u;
    /* Sleep — wakes only on reset pin or power cycle */
    for(;;) __asm__ __volatile__("sleep");

#else
    for(;;) {}
#endif
}

/* ---- Bare-bones In-Game Pause Menu (2 Options) --------- */
static u32 run_pause_menu(void) {
    u32 sel = 0;
    ZcosInput inp = {0, 0, 0, 0};
    u32 last_tick = hal_tick_get();

    const char *pause_options[2] = {
        "main menu",
        "Shut down"
    };

    for (;;) {
        u32 now = hal_tick_get();
        if ((now - last_tick) < (1000u / 30u))
            continue;
        last_tick = now;

        input_update(&inp);

        if (INP_PRESSED(&inp, BTN_UP)   && sel > 0)
            sel--;
        if (INP_PRESSED(&inp, BTN_DOWN) && sel + 1u < 2u)
            sel++;
        if (INP_PRESSED(&inp, BTN_A))
            return sel;

        /* Draw clean pause menu without artifacts or header text */
        draw_clear(COL_BLACK);

        for (u32 i = 0; i < 2u; i++) {
            u16 y  = (u16)(20u + i * 14u);
            u8  fg = (i == sel) ? COL_BLACK : COL_WHITE;
            u8  bg = (i == sel) ? COL_WHITE : COL_BLACK;
            if (i == sel)
                draw_rect(0, y, ZCOS_DISP_W, 11u, bg);
            draw_str(6u, (u16)(y + 2u), pause_options[i], fg, bg);
        }

        draw_str(2u, (u16)(ZCOS_DISP_H - 10u), "A=Select", COL_WHITE, COL_BLACK);
        hal_disp_flush();
    }
}

/* ---- Fixed Cartridge Slot Execution Model -------------- */
#define ZCOS_CARTRIDGE_SLOT ((void(*)(void))0x80200000u)

#ifdef ZCOS_SPI_STORAGE
extern void hal_spi_init(void);
extern void hal_spi_read_block(u32 address, u8 *dest, u16 len);
#endif

static void run_game(const ZcosCartridgeEntry *g) {
#ifdef ZCOS_SPI_STORAGE
    u32 offset = g->sd_offset;
    u32 size   = g->size;

    hal_uart_puts("[CARTRIDGE] Inserting ROM: ");
    hal_uart_puts(g->name);
    hal_uart_puts("\r\n");

#if defined(ZCOS_ARCH_AVR)
    if (size > 0) {
#else
    if (size > 0 && size <= 65536u) {
#endif
        /* SAFE: Copy into valid RAM at 0x80200000 */
        hal_spi_read_block(offset, (u8*)0x80200000u, (u16)size);
        hal_uart_puts("[CARTRIDGE] ROM loaded successfully. Booting...\r\n");
    } else {
        hal_uart_puts("[ERROR] Invalid ROM size!\r\n");
        return;
    }
#endif

    hal_uart_puts("[CARTRIDGE] Handing over CPU to cartridge...\r\n");
    ZCOS_CARTRIDGE_SLOT();
    hal_uart_puts("[CARTRIDGE] Cartridge removed. Returning to menu.\r\n");
    bump_reset();
}

/* ---- Game selection menu ------------------------------- */
static u32 run_menu(void) {
    u32 sel = 0;
    ZcosInput inp = {0, 0, 0, 0};
    u8 btn_a_previously_down = 1;

    for (;;) {
        input_update(&inp);

        if (INP_PRESSED(&inp, BTN_UP) && sel > 0)
            sel--;
        if (INP_PRESSED(&inp, BTN_DOWN) && sel + 1u < ZCOS_GAME_COUNT)
            sel++;
            
        if (INP_PRESSED(&inp, BTN_A)) {
            if (!btn_a_previously_down) {
                return sel;
            }
        } else {
            btn_a_previously_down = 0;
        }

        draw_clear(COL_BLACK);
        draw_hline(0, 12, ZCOS_DISP_W, COL_WHITE);
        draw_str(2u, 2u, "ZeroCOS ROM Menu", COL_WHITE, COL_BLACK);

        for (u32 i = 0; i < ZCOS_GAME_COUNT; i++) {
            u16 y = (u16)(18u + i * 10u);
            u8  fg = (i == sel) ? COL_BLACK : COL_WHITE;
            u8  bg = (i == sel) ? COL_WHITE : COL_BLACK;
            if (i == sel)
                draw_rect(0, y, ZCOS_DISP_W, 9u, bg);
            
            draw_str(6u, (u16)(y + 1u), ZCOS_GAMES[i].name, fg, bg);
        }

        draw_str(2u, (u16)(ZCOS_DISP_H - 10u), "A=Start", COL_WHITE, COL_BLACK);
        hal_disp_flush();
        hal_delay_ms(30);
    }
}

/* ---- Entry point --------------------------------------- */
int main(void) {
    hal_init();
    hal_disp_init();
    hal_sound_init();
    
#ifdef ZCOS_SPI_STORAGE
    hal_spi_init();         /* Initialize SPI bus and SD card */
#endif

    for (;;) {
        u32 sel = run_menu();
        if (sel < ZCOS_GAME_COUNT) {
            run_game(&ZCOS_GAMES[sel]);
        }
    }
}