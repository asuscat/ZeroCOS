/*
 * ZeroCOS — Copyright (C) 2026 asuscat
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

#ifndef ZCOS_GAME_LIST_H
#define ZCOS_GAME_LIST_H

#include "zcos_config.h"

typedef struct {
    const char *name;
    u32 sd_offset;
    u32 size;
} ZcosCartridgeEntry;

extern const ZcosCartridgeEntry ZCOS_GAMES[];
extern const u32 ZCOS_GAME_COUNT;

#endif /* ZCOS_GAME_LIST_H */