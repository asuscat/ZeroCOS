/*
 * ZeroCOS — Copyright (C) 2026 asuscat
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

#ifndef ZCOS_CONFIG_H
#define ZCOS_CONFIG_H

/* =========================================================
 *  ZeroCOS — compile-time tier selection
 *
 *  TIER 0  = CH32V003 real hardware        rv32ec,    2KB RAM / 16KB flash
 *  TIER 1  = CH32V203 real hardware        rv32imac, 20KB RAM / 128KB flash
 *  TIER 2  = GD32VF103 real hardware       rv32imac, 32KB RAM / 128KB flash
 *  TIER 3  = QEMU virt dev                 rv32imac, 4MB RAM, ramfb 320×240
 *  TIER 4  = ATtiny814 real hardware       avr,      512B RAM / 8KB flash
 *  TIER 5  = CH32V003 with SPI storage     rv32ec,    2KB RAM / 16KB flash
 *  TIER 6  = ATtiny814 with SPI storage     avr,      512B RAM / 8KB flash
 *  TIER 7  = QEMU virt dev with SPI storage rv32imac, 4MB RAM, ramfb 320×240
 * ========================================================= */

#ifndef ZCOS_TIER
#   define ZCOS_TIER 3
#endif

/* ---------- Tier 0: CH32V003 real hardware -------------- */
#if ZCOS_TIER == 0
#   define ZCOS_RAM_SIZE          2048u
#   define ZCOS_FLASH_SIZE        16384u
#   define ZCOS_CLOCK_HZ          48000000u
#   define ZCOS_DISP_W            128u
#   define ZCOS_DISP_H            128u
#   define ZCOS_DISP_BPP          16
#   define ZCOS_HAS_SPI_TFT       1

#   define ZCOS_HAS_UART          1
#   define ZCOS_UART_BAUD         115200u
#   define ZCOS_CHIP_CH32V003     1
#   define ZCOS_ARCH_RV32EC       1

/* ---------- Tier 1: CH32V203 real hardware -------------- */
#elif ZCOS_TIER == 1
#   define ZCOS_RAM_SIZE          (20u*1024u)
#   define ZCOS_FLASH_SIZE        (128u*1024u)
#   define ZCOS_CLOCK_HZ          144000000u
#   define ZCOS_DISP_W            240u
#   define ZCOS_DISP_H            320u
#   define ZCOS_DISP_BPP          16
#   define ZCOS_HAS_SPI_TFT       1

#   define ZCOS_HAS_UART          1
#   define ZCOS_UART_BAUD         115200u
#   define ZCOS_CHIP_CH32V203     1
#   define ZCOS_ARCH_RV32IMAC     1

/* ---------- Tier 2: GD32VF103 real hardware ------------- */
#elif ZCOS_TIER == 2
#   define ZCOS_RAM_SIZE          (32u*1024u)
#   define ZCOS_FLASH_SIZE        (128u*1024u)
#   define ZCOS_CLOCK_HZ          108000000u
#   define ZCOS_DISP_W            320u
#   define ZCOS_DISP_H            240u
#   define ZCOS_DISP_BPP          16
#   define ZCOS_HAS_SPI_TFT       1

#   define ZCOS_HAS_UART          1
#   define ZCOS_UART_BAUD         115200u
#   define ZCOS_CHIP_GD32VF103    1
#   define ZCOS_ARCH_RV32IMAC     1

/* ---------- Tier 3: QEMU virt dev (default) ------------- */
#elif ZCOS_TIER == 3
#   define ZCOS_RAM_SIZE          (4u*1024u*1024u)
#   define ZCOS_FLASH_SIZE        0u
#   define ZCOS_CLOCK_HZ          10000000u
#   define ZCOS_DISP_W            320u
#   define ZCOS_DISP_H            240u
#   define ZCOS_DISP_BPP          32
#   define ZCOS_HAS_SPI_TFT       0

#   define ZCOS_HAS_UART          1
#   define ZCOS_UART_BAUD         115200u
#   define ZCOS_CHIP_QEMU         1
#   define ZCOS_ARCH_RV32IMAC     1

/* ---------- Tier 4: ATtiny814 Tiny Dev ----------------- */
#elif ZCOS_TIER == 4
#   define ZCOS_RAM_SIZE          512u         /* 512 bytes RAM */
#   define ZCOS_FLASH_SIZE        (8u*1024u)    /* 8KB Flash */
#   define ZCOS_CLOCK_HZ          16000000u     /* 16MHz */
#   define ZCOS_DISP_W            128u          /* SSD1306 OLED width */
#   define ZCOS_DISP_H            64u           /* SSD1306 OLED height */
#   define ZCOS_DISP_BPP          1             /* 1-bit binary color */
#   define ZCOS_HAS_SPI_TFT       0
#   define ZCOS_HAS_UART          1
#   define ZCOS_UART_BAUD         9600u
#   define ZCOS_CHIP_ATTINY814    1
#   define ZCOS_ARCH_AVR          1

/* ---------- Tier 5: CH32V003 with SPI Storage --------- */
#elif ZCOS_TIER == 5
#   define ZCOS_RAM_SIZE          2048u
#   define ZCOS_FLASH_SIZE        16384u
#   define ZCOS_CLOCK_HZ          48000000u
#   define ZCOS_DISP_W            128u
#   define ZCOS_DISP_H            128u
#   define ZCOS_DISP_BPP          16
#   define ZCOS_HAS_SPI_TFT       1

#   define ZCOS_HAS_UART          1
#   define ZCOS_UART_BAUD         115200u
#   define ZCOS_CHIP_CH32V003     1
#   define ZCOS_ARCH_RV32EC       1
#   define ZCOS_SPI_STORAGE       1

/* ---------- Tier 6: ATtiny814 with SPI Storage -------- */
#elif ZCOS_TIER == 6
#   define ZCOS_RAM_SIZE          512u
#   define ZCOS_FLASH_SIZE        (8u*1024u)
#   define ZCOS_CLOCK_HZ          16000000u
#   define ZCOS_DISP_W            128u
#   define ZCOS_DISP_H            64u
#   define ZCOS_DISP_BPP          1
#   define ZCOS_HAS_SPI_TFT       0
#   define ZCOS_HAS_UART          1
#   define ZCOS_UART_BAUD         9600u
#   define ZCOS_CHIP_ATTINY814    1
#   define ZCOS_ARCH_AVR          1
#   define ZCOS_SPI_STORAGE       1

/* ---------- Tier 7: QEMU virt dev with SPI Storage ---- */
#elif ZCOS_TIER == 7
#   define ZCOS_RAM_SIZE          (4u*1024u*1024u)
#   define ZCOS_FLASH_SIZE        0u
#   define ZCOS_CLOCK_HZ          10000000u
#   define ZCOS_DISP_W            320u
#   define ZCOS_DISP_H            240u
#   define ZCOS_DISP_BPP          32
#   define ZCOS_HAS_SPI_TFT       0
#   define ZCOS_HAS_UART          1
#   define ZCOS_UART_BAUD         115200u
#   define ZCOS_CHIP_QEMU         1
#   define ZCOS_ARCH_RV32IMAC     1
#   define ZCOS_SPI_STORAGE       1

#else
#   error "Unknown ZCOS_TIER — valid: 0 1 2 3 4 5 6 7"
#endif

/* ---------- Derived constants (all tiers) --------------- */
#define ZCOS_DISP_STRIDE         (ZCOS_DISP_W * 4u)
#define ZCOS_TICK_HZ             60u
#define ZCOS_TICK_CYCLES         (ZCOS_CLOCK_HZ / ZCOS_TICK_HZ)
#define ZCOS_HEAP_SIZE           (ZCOS_RAM_SIZE / 4u)

/* ---------- Compiler attributes ------------------------- */
#define ZCOS_INLINE              __attribute__((always_inline)) static inline
#define ZCOS_NAKED               __attribute__((naked))
#define ZCOS_SECTION(s)          __attribute__((section(s)))
#define ZCOS_WEAK                __attribute__((weak))
#define ZCOS_NORETURN            __attribute__((noreturn))
#define ZCOS_PACKED              __attribute__((packed))
#define ZCOS_ALIGNED(n)          __attribute__((aligned(n)))
#define ZCOS_USED                __attribute__((used))

typedef unsigned char      u8;
typedef unsigned short     u16;
typedef unsigned int       u32;
typedef unsigned long long u64;
typedef signed char        s8;
typedef signed short       s16;
typedef signed int         s32;

#endif /* ZCOS_CONFIG_H */