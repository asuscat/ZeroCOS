#ifndef ZCOS_GAME_H
#define ZCOS_GAME_H

#include "zcos_config.h"
#include "zcos_input.h"
#include "zcos_hal.h"

/* =========================================================
 *  ZeroCOS Game Module Interface
 * ========================================================= */

typedef struct ZcosGame {
    const char *name;              /* short display name   */
    void (*init)(void);            /* called on game start */
    void (*update)(ZcosInput *inp); /* game logic tick      */
    void (*draw)(void);            /* render this frame    */
    void (*shutdown)(void);        /* optional cleanup     */
} ZcosGame;

/* Game registry — populate in games/game_list.c */
extern const ZcosGame *const zcos_game_table[];
extern const u32 zcos_game_count;

/* =========================================================
 *  Standardized Cartridge Entry Point Macro
 *  (Prevents infinite loop/speed bugs across all games)
 * ========================================================= */
#define ZCOS_RUN_CARTRIDGE(init_fn, update_fn, draw_fn) \
    void game_main(void) { \
        hal_disp_init(); /* <--- Clears screen and resets terminal cursor */ \
        init_fn(); \
        draw_fn(); \
        hal_disp_flush(); \
        while (1) { \
            ZcosInput inp; \
            *(u8*)&inp = hal_input_read(); \
            update_fn(&inp); \
            draw_fn(); \
            hal_uart_puts("\033[H"); /* <--- Forces cursor home every frame */ \
            hal_disp_flush(); \
            for (volatile u32 i = 0; i < 150000u; i++) { \
                __asm__ __volatile__("nop"); \
            } \
        } \
    }

#endif /* ZCOS_GAME_H */