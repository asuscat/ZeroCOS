#!/bin/bash
TIER=$1
if [ -z "$TIER" ]; then
    TIER=3
fi

# Check for non-SPI filename first, fallback to standard tier name
if [ -f "zerocos_tier${TIER}_spi0.elf" ]; then
    ELF="zerocos_tier${TIER}_spi0.elf"
elif [ -f "zerocos_tier${TIER}.elf" ]; then
    ELF="zerocos_tier${TIER}.elf"
else
    echo "Error: Could not find zerocos_tier${TIER}.elf or zerocos_tier${TIER}_spi0.elf"
    exit 1
fi

if [ "$TIER" = "3" ]; then
    qemu-system-riscv32 \
        -machine virt \
        -bios none \
        -nographic \
        -monitor none \
        -kernel "$ELF"
elif [ "$TIER" = "7" ]; then
    qemu-system-riscv32 \
        -machine virt \
        -bios none \
        -nographic \
        -monitor none \
        -kernel "$ELF" \
        -device loader,file=sdcard.img,addr=0x80800000
else
    echo "Unsupported QEMU tier: $TIER"
    exit 1
fi