/*
 * ZeroCOS — Copyright (C) 2026 asuscat
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

/* =========================================================
 * ZeroCOS — Kernel main
 *
 * Responsibilities:
 *   1. Hardware init (via HAL)
 *   2. Show game selection menu
 *   3. Run selected game at ZCOS_TICK_HZ with fixed timestep
 *   4. Return to menu when game exits
 *   5. TAB pause menu with "main menu" and "Shut down" options
 *
 * No malloc, no RTOS, no libc.
 * ========================================================= */

#include "zcos_config.h"
#include "zcos_hal.h"
#include "zcos_draw.h"
#include "zcos_input.h"
#include "zcos_alloc.h"

#ifdef ZCOS_SPI_STORAGE
#include "zcos_game_SPI.h"
#else
#include "zcos_game.h"
#endif

/* Ensure NULL is defined in freestanding mode */
#ifndef NULL
#define NULL ((void*)0)
#endif

/* ---- Bump allocator storage (defined here, extern in .h) */
u8  _zcos_heap[ZCOS_HEAP_SIZE] ZCOS_ALIGNED(4);
#if defined(ZCOS_ARCH_AVR)
u16 _zcos_heap_ptr = 0u;
#else
u32 _zcos_heap_ptr = 0u;
#endif

/* ---- Dynamic SD Game Registry & TOC Loader Storage --- */
#ifdef ZCOS_SPI_STORAGE
ZcosGame zcos_game_table[MAX_SD_GAMES];
u32 zcos_game_count = 0;

typedef struct {
    char name[12];
    u32 sd_offset;
    u32 size;
} __attribute__((packed)) SdGameRecord;

typedef struct {
    u8 magic[4];     /* Must be "ZCOS" */
    u8 game_count;
    SdGameRecord records[MAX_SD_GAMES];
} __attribute__((packed)) SdDirectoryHeader;

static SdDirectoryHeader s_toc_buffer;

/* Ensure SPI HAL functions are visible */
extern void hal_spi_init(void);
extern void hal_spi_read_block(u32 address, u8 *dest, u16 len);
#endif

void init_sd_game_loader(void) {
    #ifdef ZCOS_SPI_STORAGE
    zcos_game_count = 0;

    /* Read Sector 2 (byte address 0x0400) containing the TOC header */
    hal_spi_read_block(0x00000400u, (u8*)&s_toc_buffer, sizeof(SdDirectoryHeader));

    /* Validate magic signature "ZCOS" */
    if (s_toc_buffer.magic[0] == 'Z' &&
        s_toc_buffer.magic[1] == 'C' &&
        s_toc_buffer.magic[2] == 'O' &&
        s_toc_buffer.magic[3] == 'S') 
    {
        u8 count = s_toc_buffer.game_count;
        if (count > MAX_SD_GAMES) count = MAX_SD_GAMES;

        for (u8 i = 0; i < count; i++) {
            zcos_game_table[i].name = s_toc_buffer.records[i].name;
            zcos_game_table[i].type = ZCOS_GAME_TYPE_SPI;
            zcos_game_table[i].sd_offset = s_toc_buffer.records[i].sd_offset;
            zcos_game_table[i].size = s_toc_buffer.records[i].size;
            zcos_game_table[i].init = NULL;
            zcos_game_table[i].update = NULL;
            zcos_game_table[i].draw = NULL;
            zcos_game_table[i].shutdown = NULL;
        }
        zcos_game_count = count;
    }

    /* Fallback if no SD card or invalid TOC found */
    if (zcos_game_count == 0) {
        static const char *fallback_name = "No SD Card";
        zcos_game_table[0].name = fallback_name;
        zcos_game_table[0].type = ZCOS_GAME_TYPE_BUILTIN;
        zcos_game_table[0].init = NULL;
        zcos_game_table[0].update = NULL;
        zcos_game_table[0].draw = NULL;
        zcos_game_table[0].shutdown = NULL;
        zcos_game_table[0].sd_offset = 0;
        zcos_game_table[0].size = 0;
        zcos_game_count = 1;
    }
    #endif
}

/* ---- Trap handler (called from boot.S on exception) ----- */
void trap_handler(u32 cause, u32 epc) {
    hal_uart_puts("\r\n!TRAP cause=0x");
    hal_uart_puthex(cause);
    hal_uart_puts(" epc=0x");
    hal_uart_puthex(epc);
    hal_uart_puts("\r\n");
    for (;;) {}
}

/* ---- Hardware Shutdown Routine ------------------------- */
static void system_shutdown(void) {
#if defined(ZCOS_CHIP_CH32V003) || defined(ZCOS_CHIP_CH32V203)
    /* Disable peripherals */
    *(volatile u32*)(0x40013000u) = 0u; /* SPI1  */
    *(volatile u32*)(0x40012C00u) = 0u; /* TIM1  */
    *(volatile u32*)(0x40013800u + 0x0Cu) = 0u; /* USART1 */
    /* Float all GPIO to stop current drain */
    *(volatile u32*)(0x40010800u) = 0x44444444u; /* GPIOA */
    *(volatile u32*)(0x40011000u) = 0x44444444u; /* GPIOC */
    *(volatile u32*)(0x40011400u) = 0x44444444u; /* GPIOD */
    /* Enter SLEEP mode via WFI — wakes on NRST button or power cycle */
    for(;;) __asm__ __volatile__("wfi");

#elif defined(ZCOS_ARCH_AVR)
    /* Disable TCA0 timer */
    *(volatile u8*)(0x0A00u + 0x05u) = 0u;
    /* Disable TCB0 timer */
    *(volatile u8*)(0x0A40u + 0x04u) = 0u;
    /* All ports to input, no pull-up (lowest leakage) */
    *(volatile u8*)(0x0400u + 0x04u) = 0x00u; /* PORTA.DIR = input */
    *(volatile u8*)(0x0420u + 0x04u) = 0x00u; /* PORTB.DIR = input */
    /* SLPCTRL: set SMODE=PDOWN (0x2), enable SE bit (0x1) = 0x05 */
    *(volatile u8*)(0x0050u) = 0x05u;
    /* Sleep — wakes only on reset pin or power cycle */
    for(;;) __asm__ __volatile__("sleep");

#else
    for(;;) {}
#endif
}

/* ---- Bare-bones In-Game Pause Menu (2 Options) --------- */
static u32 run_pause_menu(void) {
    u32 sel = 0;
    ZcosInput inp = {0, 0, 0, 0};
    u32 last_tick = hal_tick_get();

    const char *pause_options[2] = {
        "main menu",
        "Shut down"
    };

    for (;;) {
        u32 now = hal_tick_get();
        if ((now - last_tick) < (1000u / 30u))
            continue;
        last_tick = now;

        input_update(&inp);

        if (INP_PRESSED(&inp, BTN_UP)   && sel > 0)
            sel--;
        if (INP_PRESSED(&inp, BTN_DOWN) && sel + 1u < 2u)
            sel++;
        if (INP_PRESSED(&inp, BTN_A))
            return sel;

        /* Draw clean pause menu without artifacts or header text */
        draw_clear(COL_BLACK);

        for (u32 i = 0; i < 2u; i++) {
            u16 y  = (u16)(20u + i * 14u);
            u8  fg = (i == sel) ? COL_BLACK : COL_WHITE;
            u8  bg = (i == sel) ? COL_WHITE : COL_BLACK;
            if (i == sel)
                draw_rect(0, y, ZCOS_DISP_W, 11u, bg);
            draw_str(6u, (u16)(y + 2u), pause_options[i], fg, bg);
        }

        draw_str(2u, (u16)(ZCOS_DISP_H - 10u), "A=Select", COL_WHITE, COL_BLACK);
        hal_disp_flush();
    }
}

/* ---- Fixed-step game loop (Handles SPI vs Built-in conditional paths) --- */
static void run_game(const ZcosGame *g) {
    ZcosInput inp = {0, 0, 0, 0};
    u32 last_tick = hal_tick_get();

    #ifdef ZCOS_SPI_STORAGE
    if (g->type == ZCOS_GAME_TYPE_BUILTIN) {
        if (g->init) g->init();
    } else {
        u32 offset = g->sd_offset;
        u32 size   = g->size;

        if (size > 0 && size <= ZCOS_HEAP_SIZE) {
            hal_spi_read_block(offset, _zcos_heap, (u16)size);
        }
    }
    #else
    /* Non-SPI Tiers (0-4) are always built-in */
    if (g->init) g->init();
    #endif

    for (;;) {
        u32 now = hal_tick_get();
        if ((now - last_tick) < (1000u / ZCOS_TICK_HZ))
            continue;
        last_tick = now;

        input_update(&inp);

        /* SEL+START = exit to menu */
        if (INP_PRESSED(&inp, BTN_SELECT) &&
            INP_HELD(&inp, BTN_START))
            break;

        /* START = Open 2-option pause menu */
        if (INP_PRESSED(&inp, BTN_START)) {
            u32 choice = run_pause_menu();
            if (choice == 0u) {
                break;
            } else {
                system_shutdown();
            }
        }

        #ifdef ZCOS_SPI_STORAGE
        if (g->type == ZCOS_GAME_TYPE_BUILTIN) {
            if (g->update) g->update(&inp);
            if (g->draw)   g->draw();
        } else {
            /* SPI-backed game loop ticks */
        }
        #else
        if (g->update) g->update(&inp);
        if (g->draw)   g->draw();
        #endif

        hal_disp_flush();
    }

    #ifdef ZCOS_SPI_STORAGE
    if (g->type == ZCOS_GAME_TYPE_BUILTIN) {
        if (g->shutdown) g->shutdown();
    }
    #else
    if (g->shutdown) g->shutdown();
    #endif
    
    bump_reset();
}

/* ---- Game selection menu ------------------------------- */
static u32 run_menu(void) {
    u32 sel = 0;
    ZcosInput inp = {0, 0, 0, 0};
    u32 last_tick = hal_tick_get();

    for (;;) {
        /* Throttle menu to 30 Hz — no busy-spinning */
        u32 now = hal_tick_get();
        if ((now - last_tick) < (1000u / 30u))
            continue;
        last_tick = now;

        input_update(&inp);

        if (INP_PRESSED(&inp, BTN_UP)   && sel > 0)
            sel--;
        if (INP_PRESSED(&inp, BTN_DOWN) && sel + 1u < zcos_game_count)
            sel++;
        if (INP_PRESSED(&inp, BTN_A))
            return sel;

        /* Draw menu — only once per tick, not per input poll */
        draw_clear(COL_BLACK);
        draw_hline(0, 12, ZCOS_DISP_W, COL_WHITE);

        for (u32 i = 0; i < zcos_game_count; i++) {
            u16 y  = (u16)(18u + i * 10u);
            u8  fg = (i == sel) ? COL_BLACK : COL_WHITE;
            u8  bg = (i == sel) ? COL_WHITE : COL_BLACK;
            if (i == sel)
                draw_rect(0, y, ZCOS_DISP_W, 9u, bg);
            
            #ifdef ZCOS_SPI_STORAGE
            draw_str(6u, (u16)(y + 1u), zcos_game_table[i].name, fg, bg);
            #else
            draw_str(6u, (u16)(y + 1u), zcos_game_table[i]->name, fg, bg);
            #endif
        }

        draw_str(2u, (u16)(ZCOS_DISP_H - 10u),
                 "A=Start SEL+STA=Menu", COL_WHITE, COL_BLACK);
        draw_flush();
        hal_disp_flush();
    }
}

/* ---- Entry point --------------------------------------- */
int main(void) {
    hal_init();
    hal_disp_init();
    hal_sound_init();
    
    #ifdef ZCOS_SPI_STORAGE
    hal_spi_init();         /* Initialize SPI bus and SD card */
    init_sd_game_loader();  /* Read TOC dynamically from SD card! */
    #endif

    for (;;) {
        u32 sel = run_menu();
        if (sel < zcos_game_count) {
            #ifdef ZCOS_SPI_STORAGE
            run_game(&zcos_game_table[sel]);
            #else
            run_game(zcos_game_table[sel]);
            #endif
        }
    }
}