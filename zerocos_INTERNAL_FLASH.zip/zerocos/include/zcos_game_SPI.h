/*
 * ZeroCOS — Copyright (C) 2026 asuscat
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

#ifndef ZCOS_GAME_H
#define ZCOS_GAME_H

#include "zcos_config.h"
#include "zcos_input.h"

/* Ensure NULL is defined in freestanding mode */
#ifndef NULL
#define NULL ((void*)0)
#endif

/* =========================================================
 *  ZeroCOS Game Module Interface (Unified Flat Entry)
 * ========================================================= */

typedef enum {
    ZCOS_GAME_TYPE_BUILTIN = 0,
    ZCOS_GAME_TYPE_SPI     = 1
} ZcosGameType;

typedef struct ZcosGame {
    const char *name;              /* short display name */
    ZcosGameType type;             /* distinguishes built-in vs SPI-backed */
    
    /* Function pointers (used by Built-in games) */
    void (*init)(void);
    void (*update)(ZcosInput *inp);
    void (*draw)(void);
    void (*shutdown)(void);

    /* Metadata (used by SPI-backed / SD card games) */
    u32 sd_offset;
    u32 size;
} ZcosGame;

/* Maximum number of games our dynamic loader can track at once */
#define MAX_SD_GAMES 4

/* Game registry declarations */
#ifdef ZCOS_SPI_STORAGE
/* Tiers with SPI storage use the dynamic RAM table populated at boot */
extern ZcosGame zcos_game_table[MAX_SD_GAMES];
extern u32 zcos_game_count;
void init_sd_game_loader(void);
#else
/* Standard Tiers use the static built-in game table */
extern const ZcosGame *const zcos_game_table[];
extern const u32 zcos_game_count;
#endif

#endif /* ZCOS_GAME_H */