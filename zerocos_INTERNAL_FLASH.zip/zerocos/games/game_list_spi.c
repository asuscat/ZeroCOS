/*
 * ZeroCOS — Copyright (C) 2026 asuscat
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

#include "zcos_game.h"

#ifdef __AVR__
#include <avr/pgmspace.h>
#else
#define PROGMEM
#endif

/* Only compile this static table for non-SPI tiers or as a fallback */
#ifndef ZCOS_SPI_STORAGE

const ZcosGame zcos_game_table_static[] PROGMEM = {
    {
        .name = "Frogger",
        .type = ZCOS_GAME_TYPE_SPI,
        .init = NULL,
        .update = NULL,
        .draw = NULL,
        .shutdown = NULL,
    },
    {
        .name = "1942",
        .type = ZCOS_GAME_TYPE_SPI,
        .init = NULL,
        .update = NULL,
        .draw = NULL,
        .shutdown = NULL,
    },
    {
        .name = "Arkanoid",
        .type = ZCOS_GAME_TYPE_SPI,
        .init = NULL,
        .update = NULL,
        .draw = NULL,
        .shutdown = NULL,
    }
};

const u32 zcos_game_count = sizeof(zcos_game_table_static) / sizeof(zcos_game_table_static[0]);

#endif